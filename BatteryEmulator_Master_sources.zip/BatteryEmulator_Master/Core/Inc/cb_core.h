/*
 * cb_core.h
 *
 *  Created on: 2 mag 2023
 *      Author: Alessandro
 */

#ifndef INC_CB_CORE_H_
#define INC_CB_CORE_H_

#define COM_TIMEOUT 20
#define VOLTAGE_CH 	0x08
#define CURR_CH		0x15
#define ZEROV_CODE (1<<15)

#define READ_SCALER (3-1)

#define UART_BUFSIZE    252

void modelTask(void*);
void clear_uartbuffer(void);
void send_uart (char *);
void delay_us(uint32_t);



#endif /* INC_CB_CORE_H_ */
