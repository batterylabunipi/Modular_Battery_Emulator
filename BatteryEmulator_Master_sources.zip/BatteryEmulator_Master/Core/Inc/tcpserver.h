/*
 * tcpserver.h
 *
 *  Created on: 26 apr 2023
 *      Author: Alessandro
 */

#ifndef INC_TCPSERVER_H_
#define INC_TCPSERVER_H_
#include <stdint.h>
/* INTERFACE TO CONTROL BOARD MESSAGES
 * ID: 0x00 – module configuration;
 * ID: 0x01 – calibration request;
 * ID: 0x02 – Restore ECM model to config
 * ID: 0x0A – Data Request
 * ID: 0x1y – cell y configuration ECM
 * ID: 0x1(8+y) – cell y configuration Thermal model
 * ID: 0x40 – manual cell voltage definition
 * ID: 0x41 – manual current definition
 * ID: 0x42 – manual temperature definition
 * ID: 0x70 – Model current
 * ID: 0x7F – operative mode
 *
 * CONTROL BOARD TO INTERFACE MESSAGES
 * ID: 0x80 – data_synch (auto)
 * ID: 0x9y – set/read cell voltage, current, set/read temperature cell y (auto mode)
 * ID: 0x98 – read current emulatore value (auto mode)
 * ID: 0xAy – set and read cell y voltage and current (manual)
 * ID: 0xA8 – set and read current emulator value
 * ID: 0xA9 – set & read temperature voltage
 */
// Interface --> Control Board
#define CONFIG_ID 		"00"
#define CALIB_ID		"01"
#define RESTORE_ID		"02"
#define DATAREQ_ID		"0A"
#define PARAM_ID		"1"
#define HALLPARAM_ID	"20"
#define NTCPARAM_ID		"21"
#define THERMPARAM_ID	"22"
#define MVOLTSET_ID		"40"
#define MCURRSET_ID		"41"
#define MTEMPSET_ID		"42"
#define MODCURR_ID		"70"
#define OPMODE_ID		"7F"

#define PARAM_LEN 			4
#define FPARAM_LEN			8
#define MAX_PARAM           16
#define MAX_FPARAM			53
#define HALLPARAM			2
#define NTCPARAM			5
#define THERMPARAM			4
#define NUM_CONFIG_PARAM    3
#define NUM_CALIB_PARAM     53
#define NUM_FPARAM			7 //r0, r1, c1, r2, c2, capacity, init_soc
#define ECM_PARAM_OFFSET	50
#define NUM_ECMPARAM        18
#define NUM_CELLTHERMPARAM  1



#define CONFIG_CODE		0x00
#define CALIB_CODE		0x01
#define RESTORE_CODE	0x02
#define DATAREQ_CODE	0x0A
#define PARAM_CODE		0x10
#define HALLPARAM_CODE	0x20
#define NTCPARAM_CODE	0x21
#define THERMPARAM_CODE	0x22
#define MVOLTSET_CODE	0x40
#define MCURRSET_CODE	0x41
#define MTEMPSET_CODE	0x42
#define MODCURR_CODE	0x70
#define OPMODE_CODE		0x7F

// Control Board --> Interface
#define SYNCH_ID 		"80"
#define AUTOCELL_ID		"9"
#define AUTOCURR_ID		"98"
#define MVOLTREAD_ID	"A"
#define MCURRREAD_ID	"A8"
#define MTEMPREAD_ID	"A9"

#define DEFLEN(x) (sizeof(x) - 1)
//void tcpserver_init (void);
uint8_t msg_preparser(char* msg);
void tcpTask(void *);

#endif /* INC_TCPSERVER_H_ */
