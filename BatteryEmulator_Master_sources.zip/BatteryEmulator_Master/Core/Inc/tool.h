/*
 * tool.h
 *
 *  Created on: 27 apr 2023
 *      Author: Alessandro
 */

#ifndef INC_TOOL_H_
#define INC_TOOL_H_

//includes
#include <stdint.h>


//parameters definition
#define MAX_NUM_CELL 	8
#define SOC_POINT		11

// ECM model definition
#define NO_MODEL		0
#define OCVSOC_MODEL	1
#define RINT_MODEL		2
#define _1RCMODEL		3
#define _2RCMODEL		4


// Thermal model definition
#define LUMPED_MODEL1	1

typedef struct queue_msg{
	uint8_t u8code;
	uint16_t u16param;
}queue_msg_t;

typedef struct batteryModuleParam{
	uint8_t u8cellnum;
	uint8_t u8tempboard;
	uint8_t u8currboard;
	uint8_t u8ecmmodel[MAX_NUM_CELL];
	uint8_t u8thermalmodel[MAX_NUM_CELL];
	float fsoclut [MAX_NUM_CELL][SOC_POINT];
	float frint[MAX_NUM_CELL];
	float fr1[MAX_NUM_CELL];
	float fc1[MAX_NUM_CELL];
	float fr2[MAX_NUM_CELL];
	float fc2[MAX_NUM_CELL];
	float fnomcapacity[MAX_NUM_CELL];
	float initialsoc[MAX_NUM_CELL];
	float fntc_r0;
	float fntc_beta;
	float fntc_t0;
	float fntc_vref;
	float fntc_rref;
	float fhall_currmin;
	float fhall_currmax;
	/*---------------*/
	float fthres_coreair;
	float fthres_coresurf;
	float fthermcap;
	float froomtemp;
	/*---------------*/
	float finitialtemp[MAX_NUM_CELL];
	/*---------------*/
	float f_calibdacgainc[MAX_NUM_CELL];
	float f_calibdacoffc[MAX_NUM_CELL];
	float f_calibadcgaincV[MAX_NUM_CELL];
	float f_calibadcoffcV[MAX_NUM_CELL];
	float f_calibadcgaincI[MAX_NUM_CELL];
	float f_calibadcoffcI[MAX_NUM_CELL];
	float f_calibdacgainHn;
	float f_calibdacgainHp;
	float f_calibdacoffH;
	float f_calibadcgainH;
	float f_calibadcoffH;
}batteryModuleParam_t;

typedef struct batteryModuleData{
	uint16_t u16setvoltage[MAX_NUM_CELL];
	uint16_t u16readvoltage[MAX_NUM_CELL];
	uint16_t u16cellcurrent[MAX_NUM_CELL];
	uint16_t u16setcurrent;
	uint16_t u16readcurrent;
	uint16_t u16settemperature[MAX_NUM_CELL];
	uint16_t u16readtemperature[MAX_NUM_CELL];
}batteryModuleData_t;


typedef struct cellModel{
	uint8_t u8ecmmodel;
	uint8_t u8thermalmodel;
	float fsoclut[SOC_POINT];
	float frint;
	float fr1;
	float fc1;
	float fr2;
	float fc2;
	float fv1;
	float fv2;
	float fv1_old;
	float fv2_old;
	float fcurr_old;
	float fvoltage;
	float fsoc;
	float fsoc_old;
	float fcurrcell;
	float fcurrload;
	float fnomcapacity;
	float ftau1;
	float ftau2;
	/*************/
	float ftcell;
	float ftleftsurf;
	float ftrightsurf;
	float fheatgen;
	/*************/
	float f_calibdacgainc;
	float f_calibdacoffc;
	float f_calibadcgaincV;
	float f_calibadcoffcV;
	float f_calibadcgaincI;
	float f_calibadcoffcI;

}cellModel_t ;

typedef struct reqModuleOut{ //structure for manual mode; contain the code to be set
	uint16_t u16setvoltage[MAX_NUM_CELL];
	uint16_t u16setcurrent;
	uint16_t u16settemperature[MAX_NUM_CELL];
}reqModuleOut_t;



#endif /* INC_TOOL_H_ */
