/*
 * cb_core.c
 *
 *  Created on: 2 mag 2023
 *      Author: Alessandro
 */

#include "tool.h"
#include <stdint.h>
#include "main.h"
#include "cb_core.h"
#include <stdio.h>
#include <math.h>
#include "cmsis_os.h"
#include "queue.h"
#include "tcpserver.h"
#include "semphr.h"
#include <string.h>
#include "stm32h7xx_hal_spi.h"

reqModuleOut_t reqModuleOutput;
uint8_t operative_mode = 0;
batteryModuleData_t xBatteryData;
cellModel_t BatteryModel[MAX_NUM_CELL];
GPIO_TypeDef* cs_port_DAC_cell[MAX_NUM_CELL] = {	CS_DAC_C0_GPIO_Port, CS_DAC_C1_GPIO_Port, CS_DAC_C2_GPIO_Port, CS_DAC_C3_GPIO_Port,
		CS_DAC_C4_GPIO_Port, CS_DAC_C5_GPIO_Port, CS_DAC_C6_GPIO_Port, CS_DAC_C7_GPIO_Port};
uint16_t cs_pin_DAC_cell[MAX_NUM_CELL] = {CS_DAC_C0_Pin, CS_DAC_C1_Pin, CS_DAC_C2_Pin, CS_DAC_C3_Pin, CS_DAC_C4_Pin, CS_DAC_C5_Pin, CS_DAC_C6_Pin, CS_DAC_C7_Pin};
GPIO_TypeDef* cs_port_ADC_cell[MAX_NUM_CELL] = {CS_ADC_C0_GPIO_Port, CS_ADC_C1_GPIO_Port, CS_ADC_C2_GPIO_Port, CS_ADC_C3_GPIO_Port,
		CS_ADC_C4_GPIO_Port, CS_ADC_C5_GPIO_Port, CS_ADC_C6_GPIO_Port, CS_ADC_C7_GPIO_Port};
uint16_t cs_pin_ADC_cell[MAX_NUM_CELL] = {CS_ADC_C0_Pin, CS_ADC_C1_Pin, CS_ADC_C2_Pin, CS_ADC_C3_Pin, CS_ADC_C4_Pin, CS_ADC_C5_Pin, CS_ADC_C6_Pin, CS_ADC_C7_Pin};
GPIO_TypeDef* cs_port_DAC_curr = CS_DAC_H_GPIO_Port;
uint16_t cs_pin_DAC_curr = CS_DAC_H_Pin;
GPIO_TypeDef* cs_port_ADC_curr = CS_ADC_H_GPIO_Port;
uint16_t cs_pin_ADC_curr = CS_ADC_H_Pin; 
GPIO_TypeDef* cs_port_DAC_temp = CS_DAC_T_GPIO_Port;
uint16_t cs_pin_DAC_temp = CS_DAC_T_Pin;
GPIO_TypeDef* cs_port_ADC_temp = CS_ADC_T_GPIO_Port;
uint16_t cs_pin_ADC_temp = CS_ADC_T_Pin;

extern SPI_HandleTypeDef hspi1;
extern SPI_HandleTypeDef hspi2;
extern UART_HandleTypeDef huart3;
extern TIM_HandleTypeDef htim7;

extern QueueHandle_t xQueue_tcpmsg;
extern SemaphoreHandle_t xParamMutex;
extern SemaphoreHandle_t xDataMutex;
extern SemaphoreHandle_t xreqOutMutex;
extern SemaphoreHandle_t xopModeMutex;
extern SemaphoreHandle_t xModelMutex;
extern batteryModuleParam_t xBatteryModuleParam;
extern reqModuleOut_t reqModuleOutput;
extern uint8_t operative_mode;
extern batteryModuleData_t xBatteryData;


char uart_buffer[UART_BUFSIZE];

//function prototypes
float code2CellCurrent(int16_t);
uint16_t temp2Code(float, batteryModuleParam_t);


//UART Function

//funzione per pulire il buffer della UART
void clear_uartbuffer(void)
{
	for (int i=0; i<UART_BUFSIZE; i++) uart_buffer[i] = '\0';
}

//funzione per inviare una data stringa sulla UART1
void send_uart (char *string)
{
	uint8_t len = strlen (string);
	HAL_UART_Transmit(&huart3, (uint8_t *) string, len, HAL_MAX_DELAY);
}


//auxiliary functions
//to trasform the cell voltage in the DAC code
uint16_t cellVoltage2Code(float f_voltage)
{
	uint16_t code; 
	if (f_voltage >= 0.0 && f_voltage < 5.0)
		code = (uint16_t)((f_voltage/5.0*65536.0));
	else if (f_voltage < 0.0)
		code = 0;
	else
		code = 65535;
	return code;
}


//function for setting the cell submodule ADC (DAC8501)
HAL_StatusTypeDef setCellOutput(SPI_HandleTypeDef *hspi, uint16_t CS_pin, GPIO_TypeDef* CS_port, uint16_t u16_code)
{
	//---------------REQUIRE SPI MODE2----------//
	HAL_StatusTypeDef ret_code; 
	uint8_t u8_txData [3];
	u8_txData[0] = 0x00; //mode byte, must be 0
	u8_txData[1] = (uint8_t)((u16_code >> 8)&(0xFF));
	u8_txData[2] = (uint8_t)((u16_code)&(0x00FF));
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_RESET);
	ret_code = HAL_SPI_Transmit(hspi,u8_txData, sizeof(u8_txData), COM_TIMEOUT);
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_SET);
	return ret_code;
}

//function for configuring the cell voltage submodule ADC
HAL_StatusTypeDef configCellADC(SPI_HandleTypeDef *hspi, uint16_t CS_pin, GPIO_TypeDef* CS_port)
{
	//---------------REQUIRE SPI MODE0----------//
	HAL_StatusTypeDef ret_code; 
	uint8_t u8_txData [7];	//COMMAND + config 0-1-2-3-IRQ-CH_REF
	u8_txData[0] = 0x46; 	//WRITE_CMD | ADC_ADDR | CONFIG_0 
	u8_txData[1] = 0xE3;	//NO_PART_SHUTDOWN| INTERNAL_CLK_NO_OUTPUT|NO_CURRENT_BIAS|ADC_MODE_CONVERSION
	u8_txData[2] = 0x04; 	//Oversampling 128 (0x14 per 1024)
	u8_txData[3] = 0x89;	//ADC_BIAS_CURRENT_X1|ADC_GAIN_X1|AUTO_ZERO_MUX_DISABLE|AUTO_ZERO_REF_DISABLE|CONFIG_2_RESERVED
	u8_txData[4] = 0xE0;	//CONTINUOUS_CONV|DATA_FORMAT_32|DISABLE_OFF_CAL|DISABLE_GAIN_CAL
	u8_txData[5] = 0x76; 	//IRQ_OUT|IRQ_OUT_HIGH|EN_FASTCMD|DISABLE_CONVSTART_IRQOUT|IRQ_RESERVED
	u8_txData[6] = VOLTAGE_CH;	//CH_REFp << 4 | CH_REFn
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_RESET);
	ret_code = HAL_SPI_Transmit(hspi,u8_txData, sizeof(u8_txData), COM_TIMEOUT);
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_SET);
	return ret_code;
}

HAL_StatusTypeDef readconfigCellADC(SPI_HandleTypeDef *hspi, uint16_t CS_pin, GPIO_TypeDef* CS_port, uint32_t * adcvalue)
{
	//---------------REQUIRE SPI MODE0----------//
	HAL_StatusTypeDef ret_code; 
	uint8_t u8_rxData [7];	
	uint8_t u8_txData [7];	//COMMAND + config 0-1-2-3-IRQ-CH_REF
	u8_txData[0] = 0x47; 	//WRITE_CMD | ADC_ADDR | CONFIG_0 
	u8_txData[1] = 0x00;	//NO_PART_SHUTDOWN| INTERNAL_CLK_NO_OUTPUT|NO_CURRENT_BIAS|ADC_MODE_CONVERSION
	u8_txData[2] = 0x08; 	//Oversampling 128 (0x14 per 1024)
	u8_txData[3] = 0x00;	//ADC_BIAS_CURRENT_X1|ADC_GAIN_X1|AUTO_ZERO_MUX_DISABLE|AUTO_ZERO_REF_DISABLE|CONFIG_2_RESERVED
	u8_txData[4] = 0x00;	//CONTINUOUS_CONV|DATA_FORMAT_32|DISABLE_OFF_CAL|ENABLE_GAIN_CAL
	u8_txData[5] = 0x00; 	//IRQ_OUT|IRQ_OUT_HIGH|EN_FASTCMD|DISABLE_CONVSTART_IRQOUT|IRQ_RESERVED
	u8_txData[6] = 0x00;	//CH_REFp << 4 | CH_REFn
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_RESET);	
	ret_code = HAL_SPI_TransmitReceive(hspi, u8_txData, u8_rxData,sizeof(u8_rxData),COM_TIMEOUT);
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_SET);
	*adcvalue = (((uint32_t)(u8_rxData[1]))<<24)|(((uint32_t)(u8_rxData[2]))<<16)|(((uint32_t)(u8_rxData[3]))<<8)|(((uint32_t)(u8_rxData[4]))&0xFF);
	return ret_code;
}

HAL_StatusTypeDef configCellADCgain(SPI_HandleTypeDef *hspi, uint16_t CS_pin, GPIO_TypeDef* CS_port)
{
	//---------------REQUIRE SPI MODE0----------//
	HAL_StatusTypeDef ret_code; 
	uint8_t u8_txData [4];	
	u8_txData[0] = 0x46; 	// #TO be defined
	u8_txData[1] = 0x63;	// #TO be defined
	u8_txData[2] = 0x14; 	// #TO be defined
	u8_txData[3] = 0x89;	// #TO be defined
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_RESET);
	ret_code = HAL_SPI_Transmit(hspi,u8_txData, sizeof(u8_txData), COM_TIMEOUT);
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_SET);
	return ret_code;
}

HAL_StatusTypeDef selectCellADCchannel(SPI_HandleTypeDef *hspi, uint16_t CS_pin, GPIO_TypeDef* CS_port, uint8_t channel)
{
	//---------------REQUIRE SPI MODE0----------//
	HAL_StatusTypeDef ret_code; 
	uint8_t u8_txData [2];	
	u8_txData[0] = 0x5A; 	//WRITE_CMD | ADC_ADDR | MUX)
	u8_txData[1] = channel;	//
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_RESET);
	ret_code = HAL_SPI_Transmit(hspi,u8_txData, sizeof(u8_txData), COM_TIMEOUT);
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_SET);
	return ret_code;
}

HAL_StatusTypeDef readCellADC(SPI_HandleTypeDef *hspi, uint16_t CS_pin, GPIO_TypeDef* CS_port, uint32_t* adcvalue)
{
	//---------------REQUIRE SPI MODE0----------//
	HAL_StatusTypeDef ret_code; 
	uint8_t u8_txData [5];
	uint8_t u8_rxData [5];
	u8_txData[0] = 0x41; 	// READ_CMD| ADC_ADDR | ADC_DATA
	u8_txData[1] = 0;	// 
	u8_txData[2] = 0;	// 
	u8_txData[3] = 0;	// 
	u8_txData[4] = 0;	// 
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_RESET);
	ret_code = HAL_SPI_TransmitReceive(hspi, u8_txData, u8_rxData, sizeof(u8_txData), COM_TIMEOUT);
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_SET);
//------------------------------------------------------------------------------------------------------------------------------------------------------------
	//#warning devo trasformare il codice letto in rxdata da codice a valore esadecimale e fare le due funzioni che poi lo convertono in numero vero e proprio
	*adcvalue = ~((((uint32_t)(u8_rxData[1]))<<24)|(((uint32_t)(u8_rxData[2]))<<16)|(((uint32_t)(u8_rxData[3]))<<8)|(((uint32_t)(u8_rxData[4]))&0xFF));
	//*adcvalue = ((int)u8_txData[1]<<24) | (u8_txData[1]<<16); 
//------------------------------------------------------------------------------------------------------------------------------------------------------------	
	return ret_code;
}



//function for setting the current submodule ADC (DAC8501)
HAL_StatusTypeDef setCurrOutput(SPI_HandleTypeDef *hspi, uint16_t CS_pin, GPIO_TypeDef* CS_port, uint16_t u16_code)
{
	// SPI MODE 2
	HAL_StatusTypeDef ret_code; 
	uint8_t u8_txData [3];
	u8_txData[0] = 0x00; //mode byte, must be 0
	u8_txData[1] = (uint8_t)((u16_code >> 8)&(0xFF));  
	u8_txData[2] = (uint8_t)((u16_code)&(0x00FF));
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_RESET);
	ret_code = HAL_SPI_Transmit(hspi,u8_txData, sizeof(u8_txData), COM_TIMEOUT);
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_SET);
	return ret_code;
}	

//function for triggering the measurement of the adc 
HAL_StatusTypeDef triggerCurrOutput(SPI_HandleTypeDef *hspi, uint16_t CS_pin, GPIO_TypeDef* CS_port, uint16_t u16_code)
{
	// SPI MODE 2
	HAL_StatusTypeDef ret_code; 
	uint8_t u8_txData [3];
	u8_txData[0] = 0x00; //mode byte, must be 0
	u8_txData[1] = (uint8_t)((u16_code >> 8)&(0xFF));  
	u8_txData[2] = (uint8_t)((u16_code)&(0x00FF));
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_RESET);
	ret_code = HAL_SPI_Transmit(hspi,u8_txData, sizeof(u8_txData), COM_TIMEOUT);
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_SET);
	return ret_code;
}


//function for reading the current submodule ADC (ADS8671)
HAL_StatusTypeDef readCurrOutput(SPI_HandleTypeDef *hspi, uint16_t CS_pin, GPIO_TypeDef* CS_port, uint16_t *u16_readcode)
{
	//SPI MODE 0
	HAL_StatusTypeDef ret_code; 
	uint8_t u8_txData [4] = {0,0,0,0}; // nop
	uint8_t u8_rxData [4];
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_RESET);
	// the nop operation must be repeated twice, the first start the conversion and the secondo read the result
	ret_code = HAL_SPI_Transmit(hspi,u8_txData, sizeof(u8_txData), COM_TIMEOUT);
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_SET);
	delay_us(10);
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_RESET);
	ret_code = HAL_SPI_TransmitReceive(hspi, u8_txData, u8_rxData, sizeof(u8_txData), COM_TIMEOUT);
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_SET);
	*u16_readcode = ((((uint16_t)(~u8_rxData[0]))<<6)&0x3FC0) + ((((uint16_t)(~u8_rxData[1]))&0x00FC)>>2);
	//*u16_readcode = ~((u8_rxData[0] << 6) + ((u8_rxData[1] & 0xFC) >> 2));
	return ret_code;
}

//function for configuring the current submodule ADC (ADS8671) with 5.12 voltage reference
HAL_StatusTypeDef configCurrADC(SPI_HandleTypeDef *hspi, uint16_t CS_pin, GPIO_TypeDef* CS_port)
{
	//SPI MODE 0
	HAL_StatusTypeDef ret_code;
	uint8_t u8_txData [4] = {0xD8,0x14,0x0,0x0B};//{0x0B,0x0,0x14,0xD8}; // half word set 5.12V reference (1011) on reg 0x14
	uint8_t u8_rxData [4];
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_RESET);
	// the nop operation must be repeated twice, the first start the conversion and the secondo read the result
	ret_code = HAL_SPI_Transmit(hspi,u8_txData, sizeof(u8_txData), COM_TIMEOUT);
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_SET);
	delay_us(10);
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_RESET);
	ret_code = HAL_SPI_TransmitReceive(hspi, u8_txData, u8_rxData, sizeof(u8_txData), COM_TIMEOUT);
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_SET);
	//*u16_readcode = ((((uint16_t)(~u8_rxData[0]))<<6)&0x3FC0) + ((((uint16_t)(~u8_rxData[1]))&0x00FC)>>2);
	//*u16_readcode = ~((u8_rxData[0] << 6) + ((u8_rxData[1] & 0xFC) >> 2));
	return ret_code;
}


//function for config the temperature submodule DAC (DAC12085)
HAL_StatusTypeDef configTempDAC(SPI_HandleTypeDef *hspi, uint16_t CS_pin, GPIO_TypeDef* CS_port)
{
	// SPI MODE 2
	HAL_StatusTypeDef ret_code; 
	uint8_t u8_txData [2] = {0x90,0}; //set write through mode
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_RESET);
	ret_code = HAL_SPI_Transmit(hspi,u8_txData, sizeof(u8_txData), COM_TIMEOUT); 
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_SET);
}

//function for set the output the temperature submodule DAC (DAC12085)
HAL_StatusTypeDef setTempOutput(SPI_HandleTypeDef *hspi, uint16_t CS_pin, GPIO_TypeDef* CS_port, uint16_t u16_value, uint8_t u8_channel)
{
	// SPI MODE 2
	HAL_StatusTypeDef ret_code; 
	uint8_t u8_txData [2]; 
	u8_txData[0] = (uint8_t)(((uint16_t)((u8_channel & 0x07) << 4)) | (((u16_value & 0x0F00)) >> 8));
	u8_txData[1] =  (uint8_t)((u16_value) & 0x00FF);
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_RESET);
	ret_code = HAL_SPI_Transmit(hspi,u8_txData, sizeof(u8_txData), COM_TIMEOUT); 
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_SET);
}

//function for read the temperature submodule ADC (TLV2548)
HAL_StatusTypeDef readTempOutput(SPI_HandleTypeDef *hspi, uint16_t CS_pin, GPIO_TypeDef* CS_port, uint16_t* u16_readcode, uint8_t u8_channel)
{
	// SPI MODE 0
	uint8_t u8_txData [2];
	uint8_t u8_rxData [2];
	HAL_StatusTypeDef ret_code;
	u8_txData[0] = ((u8_channel & 0x07) << 4);
	u8_txData[1] = 0x00;
	//u8_txData[2] = 0x00;
	//osDelay(2);
//	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_RESET);
//	//the nop operation must be repeated twice, the first start the conversion and the secondo read the result
//	ret_code = HAL_SPI_Transmit(hspi,u8_txData,sizeof(u8_txData), COM_TIMEOUT);
//	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_SET);
//	delay_us(10);
//	u8_txData[0] = ((u8_channel & 0x07) << 4);
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_RESET);
	delay_us(1);
	ret_code = HAL_SPI_TransmitReceive(hspi, u8_txData, u8_rxData, sizeof(u8_txData), COM_TIMEOUT);
	delay_us(1);
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_SET);
	*u16_readcode = ((((uint16_t)(~u8_rxData[0]))<<4) & 0x0FFF) + ((((uint16_t)(~u8_rxData[1]))&0x00F0)>>4);
	return ret_code;
}

//function for configuring the temperature submodule ADC (TLV2548)
HAL_StatusTypeDef configTempADC(SPI_HandleTypeDef *hspi, uint16_t CS_pin, GPIO_TypeDef* CS_port)
{
	// SPI MODE 0
	uint8_t u8_txData [2];
	HAL_StatusTypeDef ret_code;
	u8_txData[0] = 0xA0;
	u8_txData[1] = 0x04;
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_RESET);
	//the nop operation must be repeated twice, the first start the conversion and the secondo read the result
	ret_code = HAL_SPI_Transmit(hspi,u8_txData, sizeof(u8_txData), COM_TIMEOUT);
	HAL_GPIO_WritePin(CS_port, CS_pin, GPIO_PIN_SET);
	//*u16_readcode = ((((uint16_t)(~u8_rxData[0]))<<4) & 0x0FFF) + ((((uint16_t)(~u8_rxData[1]))&0x00F0)>>4);
	return ret_code;
}


void fake_send(SPI_HandleTypeDef *hspi)
 {
	HAL_SPI_Transmit(hspi, 0x00, 1, COM_TIMEOUT);
 }

void modelTask(void *arg)
{
	//HAL_StatusTypeDef ret_code;
	//uint16_t dac_code = 32768;
	uint32_t adcvalue;
	//uint32_t adcvaluecurr;
	//uint16_t adcvaluetemp;
	const TickType_t xPeriod = pdMS_TO_TICKS(100);
	TickType_t xLastWeakupTime = xTaskGetTickCount();
	uint8_t loc_opmode;
	queue_msg_t incoming_msg;
	uint8_t mchange_v = 0;
	uint8_t mchange_i = 0;
	uint8_t mchange_t = 0;
	uint8_t mchange = 0;
	uint8_t u8_configdone = 0;
	uint8_t cycle_cnt = READ_SCALER;
	reqModuleOut_t loc_reqModuleOutput;
	batteryModuleParam_t loc_xBatteryModuleParam;
	batteryModuleData_t loc_xBatteryData;
	uint8_t spi_mode = 5;
	//uint8_t read_index = 0;
	uint8_t lut_index; //ocv_soc access index
	uint8_t u8_aux = 0;
	uint8_t change_opmode = 0;
	float f_currtot = 0.0;
	float cell_ocv;
	//uint16_t set_code = 0;
	float delta_SoC;
	float delta_Temp;
	const float cycle_period = ((float)(xPeriod))/1000.0; //in seconds
	uint16_t calib_code = 0;
	////-------------------------------------PATCH FOR DISABLING TCP-IP ------------------------------//
//	loc_xBatteryModuleParam.u8cellnum = 2;
//	spi_mode = 0;
//	HAL_SPI_DeInit(&hspi1);
//	MX_SPI1_InitM0();
//	for (uint8_t i = 0; i < loc_xBatteryModuleParam.u8cellnum; i++ )
//	{
//		configCellADC(&hspi1, cs_pin_ADC_cell[i], cs_port_ADC_cell[i]);
//	}
//	u8_configdone = 1;
	///_------------------------------------------------------------------------------------------------//
	while(1)
	{
		vTaskDelayUntil(&xLastWeakupTime, xPeriod);
		xSemaphoreTake( xopModeMutex, portMAX_DELAY);
		change_opmode = loc_opmode == operative_mode ? 0 : 1;
		loc_opmode = operative_mode;
		xSemaphoreGive(xopModeMutex);
		cycle_cnt = (cycle_cnt + 1)%READ_SCALER;
		while( xQueueReceive( xQueue_tcpmsg, &incoming_msg, ( TickType_t ) 0 ) )
		{
			if(incoming_msg.u8code == MODCURR_CODE)
			{
				loc_xBatteryData.u16setcurrent = incoming_msg.u16param;
				for(uint8_t i =0; i< loc_xBatteryModuleParam.u8cellnum; i++)
				{
					BatteryModel[i].fcurrload = loc_xBatteryModuleParam.fhall_currmin + ((float)(incoming_msg.u16param)) / 65536.0 * (loc_xBatteryModuleParam.fhall_currmax - loc_xBatteryModuleParam.fhall_currmin);
				}
			}
			else if (incoming_msg.u8code == CALIB_CODE)
			{
				xSemaphoreTake( xParamMutex, portMAX_DELAY);
				loc_xBatteryModuleParam = xBatteryModuleParam;
				xSemaphoreGive(xParamMutex);
				for(uint8_t i =0; i< loc_xBatteryModuleParam.u8cellnum; i++)
				{
					BatteryModel[i].f_calibdacgainc = loc_xBatteryModuleParam.f_calibdacgainc[i];
					BatteryModel[i].f_calibdacoffc = loc_xBatteryModuleParam.f_calibdacoffc[i];
					BatteryModel[i].f_calibadcgaincV = loc_xBatteryModuleParam.f_calibadcgaincV[i];
					BatteryModel[i].f_calibadcoffcV = loc_xBatteryModuleParam.f_calibadcoffcV[i];
					BatteryModel[i].f_calibadcgaincI = loc_xBatteryModuleParam.f_calibadcgaincI[i];
					BatteryModel[i].f_calibadcoffcI = loc_xBatteryModuleParam.f_calibadcoffcI[i];
				}
				if (u8_configdone)
				{
					mchange = 1;
					mchange_v = 1;
					mchange_i = 1;
				}
			}
			else if (incoming_msg.u8code == RESTORE_CODE)
			{
				for(uint8_t i =0; i< loc_xBatteryModuleParam.u8cellnum; i++)
				{
					BatteryModel[i].fcurr_old = 0;
					BatteryModel[i].fsoc = loc_xBatteryModuleParam.initialsoc[i];
					BatteryModel[i].fsoc_old = BatteryModel[i].fsoc;
					BatteryModel[i].fv1_old = 0;
					BatteryModel[i].fv2_old = 0;
					BatteryModel[i].fcurrload = 0;
					BatteryModel[i].fcurrcell = 0;
					for(uint8_t j = 0; j < SOC_POINT; j++)
						BatteryModel[i].fsoclut[j] = loc_xBatteryModuleParam.fsoclut[i][j];
					BatteryModel[i].fr1 = loc_xBatteryModuleParam.fr1[i];
					BatteryModel[i].fr2 = loc_xBatteryModuleParam.fr2[i];
					BatteryModel[i].fc1 = loc_xBatteryModuleParam.fc1[i];
					BatteryModel[i].fc2 = loc_xBatteryModuleParam.fc2[i];
					BatteryModel[i].frint = loc_xBatteryModuleParam.frint[i];
					BatteryModel[i].ftau1 = BatteryModel[i].fr1 * BatteryModel[i].fc1;
					BatteryModel[i].ftau2 = BatteryModel[i].fr2 * BatteryModel[i].fc2;
					BatteryModel[i].fnomcapacity = loc_xBatteryModuleParam.fnomcapacity[i];
					/***** Thermal parameter *****/
					BatteryModel[i].ftleftsurf = loc_xBatteryModuleParam.froomtemp;
					BatteryModel[i].ftrightsurf = loc_xBatteryModuleParam.froomtemp;
					BatteryModel[i].fheatgen = 0;
					BatteryModel[i].ftcell = loc_xBatteryModuleParam.finitialtemp[i];
					/***** Model type *****/
					BatteryModel[i].u8ecmmodel = loc_xBatteryModuleParam.u8ecmmodel[i];
					BatteryModel[i].u8thermalmodel = loc_xBatteryModuleParam.u8thermalmodel[i];
				}
			}
			else if (incoming_msg.u8code == MVOLTSET_CODE)
			{
				mchange = 1;
				mchange_v = 1;
			}
			else if (incoming_msg.u8code == MCURRSET_CODE)
			{
				mchange = 1;
				mchange_i = 1;
			}
			else if (incoming_msg.u8code == MTEMPSET_CODE)
			{
				mchange = 1;
				mchange_t = 1;
			}
			else if(incoming_msg.u8code == CONFIG_CODE)
			{
				xSemaphoreTake( xParamMutex, portMAX_DELAY);
				loc_xBatteryModuleParam = xBatteryModuleParam;
				xSemaphoreGive(xParamMutex);
				if (spi_mode != 0)
				{
					spi_mode = 0;
					HAL_SPI_DeInit(&hspi1);
					MX_SPI1_InitM0();
					//fake_send(&hspi1);
				}
				delay_us(1);
				for (uint8_t i = 0; i < loc_xBatteryModuleParam.u8cellnum; i++ )
				{
					configCellADC(&hspi1, cs_pin_ADC_cell[i], cs_port_ADC_cell[i]);
					delay_us(1);
				}
				if(loc_xBatteryModuleParam.u8currboard == 1)
				{
					configCurrADC(&hspi1, cs_pin_ADC_curr, cs_port_ADC_curr);
					delay_us(10);
				}
				if(loc_xBatteryModuleParam.u8tempboard == 1)
				{
					if (spi_mode != 0)
					{
						spi_mode = 0;
						HAL_SPI_DeInit(&hspi1);
						MX_SPI1_InitM0();
					}
					configTempADC(&hspi1, cs_pin_ADC_temp, cs_port_ADC_temp); //set EOC active
					if (spi_mode != 2)
					{
						spi_mode = 2;
						HAL_SPI_DeInit(&hspi1);
						MX_SPI1_InitM2();
					}
					configTempDAC(&hspi1, cs_pin_DAC_temp, cs_port_DAC_temp);
				}
#warning 0-3.3 volt hall sensor
				//0-5 V sensor
				if(loc_xBatteryModuleParam.u8currboard == 1)
				{
					setCurrOutput(&hspi1, cs_pin_DAC_curr, cs_port_DAC_curr, 32768);  //set 1.65V output
					loc_xBatteryData.u16setcurrent = 32768;
				}
				u8_configdone = 1;
			}
			else if(incoming_msg.u8code == HALLPARAM_CODE)
			{
				xSemaphoreTake( xParamMutex, portMAX_DELAY);
				loc_xBatteryModuleParam = xBatteryModuleParam;
				xSemaphoreGive(xParamMutex);
			}
			else if(incoming_msg.u8code == NTCPARAM_CODE)
			{
				xSemaphoreTake( xParamMutex, portMAX_DELAY);
				loc_xBatteryModuleParam = xBatteryModuleParam;
				xSemaphoreGive(xParamMutex);
			}
			else if(incoming_msg.u8code == THERMPARAM_CODE)
			{
				xSemaphoreTake( xParamMutex, portMAX_DELAY);
				loc_xBatteryModuleParam = xBatteryModuleParam;
				xSemaphoreGive(xParamMutex);
			}
		}
		if(!loc_opmode) //manual
		{
			if(change_opmode) //have to set the default state of the components
			{
				change_opmode = 0;
				for (uint8_t i = 0; i < loc_xBatteryModuleParam.u8cellnum; i++)
				{
					selectCellADCchannel(&hspi1, cs_pin_ADC_cell[i], cs_port_ADC_cell[i], VOLTAGE_CH);
				}
				delay_us(10);
			}
			if(mchange)
			{
				mchange = 0;
				//copia semaforata dei dati richiesti
				xSemaphoreTake( xreqOutMutex, portMAX_DELAY);
				loc_reqModuleOutput = reqModuleOutput;
				xSemaphoreGive(xreqOutMutex);
				cycle_cnt = 0; //forzo aggiornamento delle letture
			}
			if(mchange_v)
			{
				mchange_v = 0;
				if (spi_mode != 2)
				{
					spi_mode = 2;
					HAL_SPI_DeInit(&hspi1);
					MX_SPI1_InitM2();
				}
				for(uint8_t i = 0; i < loc_xBatteryModuleParam.u8cellnum; i++)
				{
					calib_code = (uint16_t)((((float)loc_reqModuleOutput.u16setvoltage[i]) * BatteryModel[i].f_calibdacgainc)+BatteryModel[i].f_calibdacoffc);
					setCellOutput(&hspi1, cs_pin_DAC_cell[i], cs_port_DAC_cell[i], calib_code);
					loc_xBatteryData.u16setvoltage[i] = loc_reqModuleOutput.u16setvoltage[i];
					//delay_us(1);
				}
			}
			if(mchange_i)
			{
				mchange_i = 0;
				if (spi_mode != 2)
				{
					spi_mode = 2;
					HAL_SPI_DeInit(&hspi1);
					MX_SPI1_InitM2();
				}
				/*
				if(loc_reqModuleOutput.u16setcurrent <= ZEROV_CODE)
				{
					calib_code = (uint16_t)((((float)loc_reqModuleOutput.u16setcurrent) * loc_xBatteryModuleParam.f_calibdacgainHn)+loc_xBatteryModuleParam.f_calibdacoffH);
				}
				else
				{*/
					calib_code = (uint16_t)((((float)loc_reqModuleOutput.u16setcurrent) * loc_xBatteryModuleParam.f_calibdacgainHp)+loc_xBatteryModuleParam.f_calibdacoffH);
				//}
				setCurrOutput(&hspi1, cs_pin_DAC_curr, cs_port_DAC_curr, calib_code);
				loc_xBatteryData.u16setcurrent = loc_reqModuleOutput.u16setcurrent;
			}
			if(mchange_t)
			{
				mchange_t = 0;
				if (spi_mode != 2)
				{
					spi_mode = 2;
					HAL_SPI_DeInit(&hspi1);
					MX_SPI1_InitM2();
				}
				delay_us(10);
				fake_send(&hspi1);
				for(uint8_t i = 0; i < MAX_NUM_CELL; i++)
				{
					setTempOutput(&hspi1, cs_pin_DAC_temp, cs_port_DAC_temp, loc_reqModuleOutput.u16settemperature[i], i);
					loc_xBatteryData.u16settemperature[i] = loc_reqModuleOutput.u16settemperature[i];
					delay_us(1);
				}
			}
			if ((cycle_cnt == 0) && u8_configdone )
			{
				if(spi_mode != 0)
				{
					HAL_SPI_DeInit(&hspi1);
					spi_mode = 0;
					MX_SPI1_InitM0();
				}
				//delay_us(10);
				for(uint8_t i = 0; i < loc_xBatteryModuleParam.u8cellnum; i++) //cell voltages
				{
					readCellADC(&hspi1, cs_pin_ADC_cell[i], cs_port_ADC_cell[i], &adcvalue);
					delay_us(1);
					selectCellADCchannel(&hspi1, cs_pin_ADC_cell[i], cs_port_ADC_cell[i], CURR_CH);
					loc_xBatteryData.u16readvoltage[i] = (uint16_t)(((float)(adcvalue & ((uint32_t)(0xFFFF)))*BatteryModel[i].f_calibadcgaincV)+BatteryModel[i].f_calibadcoffcV);
				}

				delay_us(30);

				for(uint8_t i = 0; i < loc_xBatteryModuleParam.u8cellnum; i++) //cell current
				{
					readCellADC(&hspi1, cs_pin_ADC_cell[i], cs_port_ADC_cell[i], &adcvalue);
					delay_us(1);
					selectCellADCchannel(&hspi1, cs_pin_ADC_cell[i], cs_port_ADC_cell[i], VOLTAGE_CH);
					//loc_xBatteryData.u16cellcurrent[i] = (uint16_t)((adcvalue >> 1) & ((uint32_t)(0xFFFF)));
					loc_xBatteryData.u16cellcurrent[i] = (uint16_t)(((float)((adcvalue >> 1) & ((uint32_t)(0xFFFF)))-BatteryModel[i].f_calibadcoffcI)*BatteryModel[i].f_calibadcgaincI);
				}

				if(xBatteryModuleParam.u8currboard)
				{
					readCurrOutput(&hspi1, cs_pin_ADC_curr, cs_port_ADC_curr, &calib_code);
					loc_xBatteryData.u16readcurrent = (uint16_t)((((float)calib_code)* loc_xBatteryModuleParam.f_calibadcgainH) + loc_xBatteryModuleParam.f_calibadcoffH);
//					sprintf(uart_buffer, "Read output: %u\n\r", loc_xBatteryData.u16readcurrent);
//					send_uart(uart_buffer);
//					clear_uartbuffer();
				}

				if(xBatteryModuleParam.u8tempboard)
				{
					readTempOutput(&hspi1, cs_pin_ADC_temp, cs_port_ADC_temp, &loc_xBatteryData.u16readtemperature[0], 0);
					delay_us(10);
					for (uint8_t i = 0; i < 8; i++)
					{
						u8_aux = (i + 1) & 0x07;
						readTempOutput(&hspi1, cs_pin_ADC_temp, cs_port_ADC_temp, &loc_xBatteryData.u16readtemperature[i], u8_aux);
						delay_us(10);
					}
				}

				//copy of the data in the global structure
				xSemaphoreTake( xDataMutex, portMAX_DELAY);
				xBatteryData = loc_xBatteryData;
				xSemaphoreGive(xDataMutex);
			}
		}
		else //automatic mode
		{
			if(change_opmode) //have to set the default state of the components
			{
				change_opmode = 0;
				if (spi_mode != 0)
				{
					spi_mode = 0;
					HAL_SPI_DeInit(&hspi1);
					MX_SPI1_InitM0();
				}
				for (uint8_t i = 0; i < loc_xBatteryModuleParam.u8cellnum; i++)
				{
					selectCellADCchannel(&hspi1, cs_pin_ADC_cell[i], cs_port_ADC_cell[i], CURR_CH);
				}
				delay_us(10);
			}

			//leggere dall'ADC delle celle le correnti
			for(uint8_t i = 0; i < loc_xBatteryModuleParam.u8cellnum; i++) //cell current
			{
				/***** Read cell current using ADC *****/
				readCellADC(&hspi1, cs_pin_ADC_cell[i], cs_port_ADC_cell[i], &adcvalue);
				selectCellADCchannel(&hspi1, cs_pin_ADC_cell[i], cs_port_ADC_cell[i], VOLTAGE_CH);
				//loc_xBatteryData.u16cellcurrent[i] = (uint16_t)((adcvalue >> 1) & ((uint32_t)(0xFFFF)));
				loc_xBatteryData.u16cellcurrent[i] = (uint16_t)(((float)((adcvalue >> 1) & ((uint32_t)(0xFFFF)))-BatteryModel[i].f_calibadcoffcI)*BatteryModel[i].f_calibadcgaincI);
				BatteryModel[i].fcurrcell = code2CellCurrent((int16_t)loc_xBatteryData.u16cellcurrent[i]);
				/***** Update Electrical Circuit Model  *****/
				f_currtot = BatteryModel[i].fcurrcell + BatteryModel[i].fcurrload;
				BatteryModel[i].fsoc = BatteryModel[i].fsoc_old - (f_currtot + BatteryModel[i].fcurr_old) /(BatteryModel[i].fnomcapacity * 7200)*cycle_period;
				lut_index = (uint32_t)(BatteryModel[i].fsoc * 10.0);
				if (lut_index < 0)
					lut_index = 0;
				if (lut_index > 9)
					lut_index = 9;
				delta_SoC = BatteryModel[i].fsoc - ((float)lut_index)*0.1;
				cell_ocv = BatteryModel[i].fsoclut[lut_index] + (BatteryModel[i].fsoclut[lut_index+1] - BatteryModel[i].fsoclut[lut_index]) * delta_SoC * 10.0;
				// Vc1/2
				if(BatteryModel[i].u8ecmmodel >= _1RCMODEL)
				{
					BatteryModel[i].fv1 = BatteryModel[i].fv1_old * (2.0 * BatteryModel[i].ftau1 - cycle_period) / (2.0*BatteryModel[i].fr1);
					BatteryModel[i].fv1 = BatteryModel[i].fv1 + ((BatteryModel[i].fcurr_old + f_currtot)*cycle_period / 2.0);
					BatteryModel[i].fv1 = BatteryModel[i].fv1 / (2.0 * BatteryModel[i].ftau1 + cycle_period) * 2*BatteryModel[i].fr1;
				}
				if(BatteryModel[i].u8ecmmodel >= _2RCMODEL)
				{
					BatteryModel[i].fv2 = BatteryModel[i].fv2_old * (2.0 * BatteryModel[i].ftau2 - cycle_period) / (2.0*BatteryModel[i].fr2);
					BatteryModel[i].fv2 = BatteryModel[i].fv2 + ((BatteryModel[i].fcurr_old + f_currtot)*cycle_period / 2.0);
					BatteryModel[i].fv2 = BatteryModel[i].fv2 / (2.0 * BatteryModel[i].ftau2 + cycle_period) * 2*BatteryModel[i].fr2;
				}
				//output value
				BatteryModel[i].fvoltage = cell_ocv - BatteryModel[i].frint * f_currtot - BatteryModel[i].fv1 - BatteryModel[i].fv2;
				/***** Update Thermal Model  *****/
				if(BatteryModel[i].u8thermalmodel >= LUMPED_MODEL1)
				{
					delta_Temp = BatteryModel[i].fheatgen - (BatteryModel[i].ftcell - loc_xBatteryModuleParam.froomtemp)/loc_xBatteryModuleParam.fthres_coreair;
					delta_Temp = delta_Temp - (2.0 * BatteryModel[i].ftcell - BatteryModel[i].ftleftsurf - BatteryModel[i].ftrightsurf) / loc_xBatteryModuleParam.fthres_coresurf;
					delta_Temp = cycle_period / loc_xBatteryModuleParam.fthermcap * delta_Temp;
					BatteryModel[i].ftcell += delta_Temp;
					//heat generation to be used in the next step
					BatteryModel[i].fheatgen = (BatteryModel[i].fvoltage - cell_ocv) * f_currtot;
				}
			}
			/***** Update surface temperature once all the temperature are computed  *****/
			for(uint8_t i = 0; i < loc_xBatteryModuleParam.u8cellnum - 1; i++)
			{
				BatteryModel[i].ftrightsurf = (BatteryModel[i].ftcell + BatteryModel[i+1].ftcell) / 2.0;
			}
			for(uint8_t i = 1; i < loc_xBatteryModuleParam.u8cellnum; i++)
			{
				BatteryModel[i].ftleftsurf = (BatteryModel[i].ftcell + BatteryModel[i-1].ftcell) / 2.0;
			}


			//aggiornare le uscite dei blocchi
			if (spi_mode != 2)
			{
				spi_mode = 2;
				HAL_SPI_DeInit(&hspi1);
				MX_SPI1_InitM2();
			}
			for(uint8_t i = 0; i < loc_xBatteryModuleParam.u8cellnum; i++)
			{
				loc_xBatteryData.u16setvoltage[i] = cellVoltage2Code(BatteryModel[i].fvoltage);
				calib_code = (uint16_t)((((float)loc_xBatteryData.u16setvoltage[i]) * BatteryModel[i].f_calibdacgainc)+BatteryModel[i].f_calibdacoffc);
				setCellOutput(&hspi1, cs_pin_DAC_cell[i], cs_port_DAC_cell[i], calib_code);
			}
			if(loc_xBatteryModuleParam.u8currboard)
			{
				if (spi_mode != 2)
				{
					spi_mode = 2;
					HAL_SPI_DeInit(&hspi1);
					MX_SPI1_InitM2();
				}
				/*
				if(loc_xBatteryData.u16setcurrent <= ZEROV_CODE)
				{
					calib_code = (uint16_t)((((float)loc_xBatteryData.u16setcurrent) * loc_xBatteryModuleParam.f_calibdacgainHn)+loc_xBatteryModuleParam.f_calibdacoffH);
				}
				else
				{*/
					calib_code = (uint16_t)((((float)loc_xBatteryData.u16setcurrent) * loc_xBatteryModuleParam.f_calibdacgainHp)+loc_xBatteryModuleParam.f_calibdacoffH);
				//}
				//calib_code = (uint16_t)((((float) loc_xBatteryData.u16setcurrent) * loc_xBatteryModuleParam.f_calibdacgainHp) + loc_xBatteryModuleParam.f_calibdacoffH);
				setCurrOutput(&hspi1, cs_pin_DAC_curr, cs_port_DAC_curr, calib_code);
			}
			if(loc_xBatteryModuleParam.u8tempboard)
			{
				if (spi_mode != 2)
				{
					spi_mode = 2;
					HAL_SPI_DeInit(&hspi1);
					MX_SPI1_InitM2();
				}
				for( uint8_t i = 0; i < loc_xBatteryModuleParam.u8cellnum; i++)
				{
					loc_xBatteryData.u16settemperature[i] = temp2Code(BatteryModel[i].ftcell, loc_xBatteryModuleParam);
					setTempOutput(&hspi1, cs_pin_DAC_temp, cs_port_DAC_temp, loc_xBatteryData.u16settemperature[i], i);
					delay_us(1);
				}
			}
			//lettura valori
			if(spi_mode != 0)
			{
				HAL_SPI_DeInit(&hspi1);
				spi_mode = 0;
				MX_SPI1_InitM0();
			}
			for(uint8_t i = 0; i < loc_xBatteryModuleParam.u8cellnum; i++) //cell voltages
			{
				readCellADC(&hspi1, cs_pin_ADC_cell[i], cs_port_ADC_cell[i], &adcvalue);
				selectCellADCchannel(&hspi1, cs_pin_ADC_cell[i], cs_port_ADC_cell[i], CURR_CH);
				//loc_xBatteryData.u16readvoltage[i] = (uint16_t)(adcvalue & ((uint32_t)(0xFFFF)));
				loc_xBatteryData.u16readvoltage[i] =(uint16_t)(((float)(adcvalue & ((uint32_t)(0xFFFF)))*BatteryModel[i].f_calibadcgaincV)+BatteryModel[i].f_calibadcoffcV);
			}

			if(xBatteryModuleParam.u8currboard)
			{
				readCurrOutput(&hspi1, cs_pin_ADC_curr, cs_port_ADC_curr, &calib_code);
				loc_xBatteryData.u16readcurrent = (uint16_t)((((float)calib_code)* loc_xBatteryModuleParam.f_calibadcgainH) + loc_xBatteryModuleParam.f_calibadcoffH);
			}

			if(xBatteryModuleParam.u8tempboard)
			{
				readTempOutput(&hspi1, cs_pin_ADC_temp, cs_port_ADC_temp, &loc_xBatteryData.u16readtemperature[0], 0);
				for (uint8_t i = 0; i < loc_xBatteryModuleParam.u8cellnum; i++)
				{
					delay_us(8);
					u8_aux = (i + 1) & 0x07;
					readTempOutput(&hspi1, cs_pin_ADC_temp, cs_port_ADC_temp, &loc_xBatteryData.u16readtemperature[i], u8_aux);
				}
			}
			//salvare i valori presenti nell'"old" di quelli che servono
			for(uint8_t i =0; i< loc_xBatteryModuleParam.u8cellnum; i++)
			{
				BatteryModel[i].fcurr_old = BatteryModel[i].fcurrload + BatteryModel[i].fcurrcell;
				BatteryModel[i].fsoc_old = BatteryModel[i].fsoc;
				BatteryModel[i].fv1_old = BatteryModel[i].fv1;
				BatteryModel[i].fv2_old = BatteryModel[i].fv2;
			}

			//copy of the data in the global structure
			xSemaphoreTake( xDataMutex, portMAX_DELAY);
			xBatteryData = loc_xBatteryData;
			xSemaphoreGive(xDataMutex);
		}
	}
}
/*
float code2Temp(uint16_t value, float vlevel, batteryModuleParam_t moduleParam) //vlevel is the reference value of the thermistor circuit
{
	float t0 = moduleParam.fntc_t0; //reference temperature for thermistor
	float Rpart = moduleParam.fntc_rref; //resistor of voltage divider
	float R0 = moduleParam.fntc_r0; // thermistor resistance value at reference temperature
	float Vdac = 5.0f; //reference voltage of ADC 
	float num_codes = 4096.0f; //number of codes of ADC 
	float beta = moduleParam.fntc_beta; //beta value of thermistor
	float Vout, Temp; 
	Vout = ((float)value)*Vdac / num_codes;
	Temp = 1.0 / t0 + (1.0 / beta)*logf(Vout*Rpart/(vlevel-Vout)/R0);
	Temp = 1.0 / Temp;
	return Temp;
}
*/
uint16_t temp2Code(float temp, batteryModuleParam_t moduleParam)
{
	float rt;
	float refto5vPartition = 0.66; //3.3 diviso 5V
	uint16_t code;
	rt = moduleParam.fntc_r0 * exp(moduleParam.fntc_beta*(1/temp - 1/moduleParam.fntc_t0));
	code = (uint16_t)((rt /(rt + moduleParam.fntc_rref) * 4096.0)*refto5vPartition);
	return code;
}



float code2CellCurrent(int16_t value)
{
	//float Vref = 2.4; //reference voltage of ADC
	//float num_codes = 65536.0f; //number of codes of ADC
	//float ina_gain = 50.0f;
	//float rshunt = 0.005f;
	float scale_factor = 0.0005859375; //keep in count 16 bit rapresentation, voltage divider , Vref, shunt, and INA gain (and 2x correction)
	float curr;
	curr = ((float)value)*scale_factor;///num_codes*2.0f*Vref/ina_gain/rshunt;
	return curr;
	//_value = float(value) / 65536.0 * 2.0 * 2.40 * 4.0 * 2 //keep in count voltage divider , Vref, shunt, and INA gain (and 2x correction)
}


inline void delay_us(uint32_t us)
{
	__HAL_TIM_SET_COUNTER(&htim7,0);  // set the counter value a 0
	while (__HAL_TIM_GET_COUNTER(&htim7) < us);  // wait for the counter to reach the us input in the parameter
}
/* funzione per intercettare in debug gli stackoverflow.

attivare il debug e mettere un breakpoint in questa funzione, guardando le variabile task_overflowed_name

ci dovrei leggere il nome dell'ultimo task in esecuzione(ovvero quello che ha fallito)

NB: AD OGNI GENERAZIONE DEL .IOC configCHECK_FOR_STACK_OVERFLOW VIENE RIMESSO A 0 (freertos.h)

*/
/*
void vApplicationStackOverflowHook(TaskHandle_t* pxTask, char* pcTaskName ){
	__disable_irq();
	HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_SET);// accendo un led sulla nucleo per indicare che sono finito in stack overflow
	TaskHandle_t task_overflowed = &pxTask;
	char task_overflowed_name[50];
	memcpy(task_overflowed_name, pcTaskName, strlen(pcTaskName) );
	while(1){};
}
*/
