/*
 * tcpserver.c
 *
 *  Created on: 26 apr 2023
 *      Author: Alessandro
 */


#include "lwip/opt.h"

#include "lwip/api.h"
#include "lwip/sys.h"
#include "lwip/tcpip.h"

#include "tcpserver.h"
#include "string.h"
#include "tool.h"
#include "queue.h"
#include "semphr.h"
#include "cb_core.h"
#include <lwip/stats.h>



extern QueueHandle_t xQueue_tcpmsg;
extern SemaphoreHandle_t xParamMutex;
extern SemaphoreHandle_t xDataMutex;
extern SemaphoreHandle_t xreqOutMutex;
extern SemaphoreHandle_t xopModeMutex;
extern SemaphoreHandle_t xModelMutex;
extern batteryModuleParam_t xBatteryModuleParam;
extern reqModuleOut_t reqModuleOutput;
extern uint8_t operative_mode;
extern batteryModuleData_t xBatteryData;

static struct netconn *conn, *newconn;
static struct netbuf *buf;
char msg[1024];
char smsg[200];
extern cellModel_t BatteryModel[MAX_NUM_CELL];

//------------------------------------------------------------------//
#warning da rimuovere, sono per debug
extern UART_HandleTypeDef huart3;
extern char uart_buffer[UART_BUFSIZE];
//------------------------------------------------------------------//

//-------------------------------------------Auxiliary functions -----------------------------------------------//
uint16_t str2u16(char* str)
{
    uint16_t res = 0;
    char c,v;
    //while ((c = *str++)) {
    for (uint8_t i =0; i< 4; i++){
    	c = *str++;
        v = ((c & 0xF) + (c >> 6)) | ((c >> 3) & 0x8);
        res = (res << 4) | (uint16_t) v;
    }
    return res;
}


float str2float(char* str)
{
    float res;
    uint32_t aux = 0;
    char c,v;
    for (uint8_t i =0; i< 8; i++){
    	c = *str++;
        v = ((c & 0xF) + (c >> 6)) | ((c >> 3) & 0x8);
        aux = (aux << 4) | ((uint32_t) v);
    }
    res = *(float*)(&aux);
    return res;
}

void appendu16tostr(uint16_t num, char* str)
{
    uint8_t dec;
    for(int i =0; i<4; i++)
    {
        dec = (uint8_t)((num >> (12-4*i)) & ((uint32_t)0x0F));
        if(dec<10)
            str[i] = dec + 0x30;
        else
            str[i] = dec + 0x37 ;
    }
}

/**** Send RESPONSE every time the client sends some data ******/
void tcpTask(void *arg)
{
	err_t err, accept_err; // recv_error;
	uint16_t cell_index;
	char header[3] = {'\0','\0','\0'};
	char aux_str[FPARAM_LEN+1];
	uint16_t paramlist [MAX_PARAM];
	float f_paramlist [MAX_FPARAM];
	queue_msg_t que_msg;
	batteryModuleData_t auxBatteryData;
	char *token;
	char separator [] = "\n";
	char aux_c;
	uint8_t loc_opmode = 0;
	uint8_t loc_numcell = 0;
	uint8_t loc_currboard = 0;
	uint8_t loc_tempboard = 0;
	uint8_t model_type = 0;
	//reqModuleOut_t auxreqModuleOut;
	/* Create a new connection identifier. */
	conn = netconn_new(NETCONN_TCP);
	if (conn!=NULL)
	{
		/* Bind connection to the port number 7. */
		err = netconn_bind(conn, IP_ADDR_ANY, 7);
		if (err == ERR_OK)
		{
			/* Tell connection to go into listening mode. */
			netconn_listen(conn);
			while (1)
			{
				/* Grab new connection. */
				accept_err = netconn_accept(conn, &newconn);

				/* Process the new connection. */
				if (accept_err == ERR_OK)
				{

					/* receive the data from the client */
					while(netconn_recv(newconn, &buf) == ERR_OK)
					{
						do
						{
							/*MSGs can be appended, so they have to be isolated before parsing get the first token */
							strncpy (msg, buf->p->payload, buf->p->len);   // get the message from the client
							token = strtok(msg, separator);

							/* walk through other tokens */
							while( token != NULL ) {
								memset(header, '\0', sizeof(header));
								strncpy(header, token, sizeof(header) - 1);
								if (strncmp(header, MODCURR_ID, DEFLEN(MODCURR_ID)) == 0) //massima priorità, quello che deve essere gestito
								{
									que_msg.u8code = MODCURR_CODE;
									que_msg.u16param = str2u16(token+2);
									xQueueSend( xQueue_tcpmsg, ( void * ) &que_msg, ( TickType_t ) 10);
									//----------------------------------------------------------------
									sprintf(uart_buffer, "MSG - Code:%X\t Param:%X\n\r", que_msg.u8code, que_msg.u16param );
									send_uart(uart_buffer);
									//HAL_Delay(10);
									clear_uartbuffer();
								}
								else if (strncmp(header, OPMODE_ID, DEFLEN(OPMODE_ID)) == 0) //change of operative mode
								{
									paramlist[0] = str2u16(token+2);
									loc_opmode = (uint8_t)paramlist[0];
									xSemaphoreTake( xopModeMutex, portMAX_DELAY);
									operative_mode = (uint8_t)paramlist[0];
									xSemaphoreGive(xopModeMutex);
									//-------------------------------------------------------------------------------
									sprintf(uart_buffer, "MSG - OPMODE\tParam:%X\n\r",operative_mode );
									send_uart(uart_buffer);
									//HAL_Delay(10);
									clear_uartbuffer();
								}
								else if (strncmp(header, DATAREQ_ID, DEFLEN(DATAREQ_ID)) == 0) // data request from interface
								{
									xSemaphoreTake( xDataMutex, portMAX_DELAY);
									auxBatteryData = xBatteryData;
									xSemaphoreGive( xDataMutex );
									//-------------------------------------------------------------------------------
									sprintf(uart_buffer, "MSG - DATA Request\n\r");
									send_uart(uart_buffer);
									//HAL_Delay(10);
									clear_uartbuffer();
									if(loc_opmode) //auto_mode
									{
										for(uint8_t i = 0; i< loc_numcell; i++)
										{
											memset(smsg, '\0', sizeof(smsg));
											smsg[0] = '9';
											smsg[1] = i + 0x30; // convert an integer in the relative char 0 -> '0'
											appendu16tostr(auxBatteryData.u16setvoltage[i], smsg+2);
											appendu16tostr(auxBatteryData.u16readvoltage[i], smsg+6);
											appendu16tostr(auxBatteryData.u16cellcurrent[i], smsg+10);
											appendu16tostr(auxBatteryData.u16settemperature[i], smsg+14);
											appendu16tostr(auxBatteryData.u16readtemperature[i], smsg+18);
											smsg[22] = '\n';
											netconn_write(newconn, smsg, 23, NETCONN_COPY);
										}
										if(loc_currboard)
										{
											memset(smsg, '\0', sizeof(smsg));
											smsg[0] = '9';
											smsg[1] = '8'; //
											appendu16tostr(auxBatteryData.u16setcurrent, smsg+2);
											appendu16tostr(auxBatteryData.u16readcurrent, smsg+6);
											smsg[10] = '\n';
											netconn_write(newconn, smsg, 11, NETCONN_COPY);
										}

										//synch message
										memset(smsg, '\0', sizeof(smsg));
										smsg[0] = '8';
										smsg[1] = '0';
										smsg[2] = '\n';
										netconn_write(newconn, smsg, 3, NETCONN_COPY);

									}
									else //manual
									{

										for(uint8_t i = 0; i< loc_numcell; i++)
										{
											memset(smsg, '\0', sizeof(smsg));
											smsg[0] = 'A';
											smsg[1] = i + 0x30; // convert an integer in the relative char 0 -> '0'
											appendu16tostr(auxBatteryData.u16setvoltage[i], smsg+2);
											appendu16tostr(auxBatteryData.u16readvoltage[i], smsg+6);
											appendu16tostr(auxBatteryData.u16cellcurrent[i], smsg+10);
											smsg[14] = '\n';
											netconn_write(newconn, smsg, 15, NETCONN_COPY);
										}
										if(loc_currboard)
										{
											memset(smsg, '\0', sizeof(smsg));
											smsg[0] = 'A';
											smsg[1] = '8'; //
											appendu16tostr(auxBatteryData.u16setcurrent, smsg+2);
											appendu16tostr(auxBatteryData.u16readcurrent, smsg+6);
											smsg[10] = '\n';
											netconn_write(newconn, smsg, 11, NETCONN_COPY);
										}
										if(loc_tempboard)
										{
											memset(smsg, '\0', sizeof(smsg));
											smsg[0] = 'A';
											smsg[1] = '9';
											for (uint8_t i = 0; i< MAX_NUM_CELL; i++)
											{
												appendu16tostr(auxBatteryData.u16settemperature[i], smsg+2+4*i);
												appendu16tostr(auxBatteryData.u16readtemperature[i], smsg+34+4*i);
												smsg[66] = '\n';
											}
											//send_uart(smsg);
											netconn_write(newconn, smsg, 67, NETCONN_COPY);
										}
										//synch message
										memset(smsg, '\0', sizeof(smsg));
										smsg[0] = '8';
										smsg[1] = '1';
										smsg[2] = '\n';
										netconn_write(newconn, smsg, 3, NETCONN_COPY);
									}

								}
								else if (strncmp(header, CONFIG_ID, DEFLEN(CONFIG_ID)) == 0) // module configuration
								{
									for (int i = 0; i < NUM_CONFIG_PARAM; i++)
									{
										memset(aux_str, '\0', sizeof(aux_str));
										strncpy(aux_str, token + 2 + PARAM_LEN*i, PARAM_LEN);
										paramlist[i] = str2u16(aux_str);
									}
									//------------------------------------------------------------------------------------------------------------------
									sprintf(uart_buffer, "MSG - CONFIG \tParams:\t%X\t%X\t%X\n\r", paramlist[0], paramlist[1], paramlist[2]);
									send_uart(uart_buffer);
									//HAL_Delay(10);
									clear_uartbuffer();
									loc_numcell = (uint8_t) paramlist[0];
									loc_currboard = (uint8_t) paramlist[1];
									loc_tempboard = (uint8_t) paramlist[2];
									xSemaphoreTake( xParamMutex, portMAX_DELAY);
									/* critical section*/
									xBatteryModuleParam.u8cellnum = (uint8_t) paramlist[0];
									xBatteryModuleParam.u8currboard = (uint8_t) paramlist[1];
									xBatteryModuleParam.u8tempboard = (uint8_t) paramlist[2];
									xSemaphoreGive( xParamMutex );
									que_msg.u8code = CONFIG_CODE;
									que_msg.u16param = 0;
									xQueueSend( xQueue_tcpmsg, ( void * ) &que_msg, ( TickType_t ) 10);

								}
								else if (strncmp(header, CALIB_ID, DEFLEN(CALIB_ID)) == 0) //calibration request
								{
									que_msg.u8code = CALIB_CODE;
									que_msg.u16param = 0;
									for (uint8_t i = 0; i < NUM_CALIB_PARAM; i++)
									{
										memset(aux_str, '\0', sizeof(aux_str));
										strncpy(aux_str, token + 2 + FPARAM_LEN*i, FPARAM_LEN);
										f_paramlist[i] = str2float(aux_str);
									}
									//------------------------------------------------------------------------------------------------------------------
									sprintf(uart_buffer, "MSG- CALIB \tParams:%X\t%X\t%X\n\r", paramlist[0], paramlist[1], paramlist[2]);
									send_uart(uart_buffer);
									//HAL_Delay(10);
									clear_uartbuffer();
									/* critical section*/
									xSemaphoreTake( xParamMutex, portMAX_DELAY);
									for (uint8_t i = 0; i < MAX_NUM_CELL; i++)
									{
										xBatteryModuleParam.f_calibdacgainc[i] = f_paramlist[6*i];
										xBatteryModuleParam.f_calibdacoffc[i] = f_paramlist[6*i+1];
										xBatteryModuleParam.f_calibadcgaincV[i] = f_paramlist[6*i+2];
										xBatteryModuleParam.f_calibadcoffcV[i] = f_paramlist[6*i+3];
										xBatteryModuleParam.f_calibadcgaincI[i] = f_paramlist[6*i+4];
										xBatteryModuleParam.f_calibadcoffcI[i] = f_paramlist[6*i+5];
									}
									xBatteryModuleParam.f_calibdacgainHn = f_paramlist[48];
									xBatteryModuleParam.f_calibdacgainHp = f_paramlist[49];
									xBatteryModuleParam.f_calibdacoffH = f_paramlist[50];
									xBatteryModuleParam.f_calibadcgainH = f_paramlist[51];
									xBatteryModuleParam.f_calibadcoffH = f_paramlist[52];
									xSemaphoreGive( xParamMutex );
									xQueueSend( xQueue_tcpmsg, ( void * ) &que_msg, ( TickType_t ) 10);

								}
								else if (strncmp(header, RESTORE_ID, DEFLEN(RESTORE_ID)) == 0) // restore model to init value
								{
									que_msg.u8code = RESTORE_CODE;
									que_msg.u16param = 0;
									xQueueSend( xQueue_tcpmsg, ( void * ) &que_msg, ( TickType_t ) 10);
									//------------------------------------------------------------------------------------------------------------------
									sprintf(uart_buffer, "MSG-Restore\n\r");
									send_uart(uart_buffer);
									//HAL_Delay(10);
									clear_uartbuffer();
								}
								else if (strncmp(header, PARAM_ID, DEFLEN(PARAM_ID)) == 0) //ECM or Thermal parameters of the cell
								{
									aux_c = token[1];
									cell_index = ((aux_c & 0xF) + (aux_c >> 6)) | ((aux_c >> 3) & 0x8);
									if(cell_index < MAX_NUM_CELL) //ECM
									{
										//acquire the cell model
										memset(aux_str, '\0', sizeof(aux_str));
										strncpy(aux_str, token + 2, PARAM_LEN);
										model_type = (uint8_t)str2u16(aux_str);
										//acquire the 11 SOC point (uint16_t)
										for (uint8_t i = 0; i < SOC_POINT; i++)
										{
											memset(aux_str, '\0', sizeof(aux_str));
											strncpy(aux_str, token + 6 + PARAM_LEN*i, PARAM_LEN);
											paramlist[i] = str2u16(aux_str);
										}
										for (uint8_t i = 0; i < NUM_FPARAM; i++)
										{	//r0, r1, c1, r2, c2, capacity, init_soc
											memset(aux_str, '\0', sizeof(aux_str));
											strncpy(aux_str, token + ECM_PARAM_OFFSET + FPARAM_LEN*i, FPARAM_LEN);
											f_paramlist[i] = str2float(aux_str);
										}

										//------------------------------------------------------------------------------------------------------------------
										//sprintf(uart_buffer, "MSG - CELL %x PARAM: %d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n\r", cell_index, paramlist[0], paramlist[1], paramlist[2],
											//paramlist[3], paramlist[4], paramlist[5], paramlist[6], paramlist[7], paramlist[8], paramlist[9], paramlist[10], paramlist[11], paramlist[12]);
										//sprintf(uart_buffer, "MSG- CELL %x PARAM: %d\n\r",cell_index,  );
										//send_uart(uart_buffer);
										//HAL_Delay(10);
										//clear_uartbuffer();
										xSemaphoreTake( xParamMutex, portMAX_DELAY);
										for(int i = 0; i < SOC_POINT; i++)
										{
											xBatteryModuleParam.fsoclut[cell_index][i] = (float) (paramlist[i]/10000.0);
										}
										xBatteryModuleParam.u8ecmmodel[cell_index] = model_type;
										xBatteryModuleParam.frint[cell_index] = f_paramlist[0];
										xBatteryModuleParam.fr1[cell_index] = f_paramlist[1];
										xBatteryModuleParam.fc1[cell_index] = f_paramlist[2];
										xBatteryModuleParam.fr2[cell_index] = f_paramlist[3];
										xBatteryModuleParam.fc2[cell_index] = f_paramlist[4];
										xBatteryModuleParam.fnomcapacity[cell_index] = f_paramlist[5];
										xBatteryModuleParam.initialsoc[cell_index] = f_paramlist[6];
										xSemaphoreGive(xParamMutex);
									}
									else
									{
										//devo ricavare l'indicazione della cella dall'id, devo marchiare il tipo di modello e
										cell_index -= 8;
										memset(aux_str, '\0', sizeof(aux_str));
										strncpy(aux_str, token + 2, PARAM_LEN);
										model_type = (uint8_t)str2u16(aux_str);
										for (uint8_t i = 0; i < NUM_CELLTHERMPARAM; i++)
										{	//r0, r1, c1, r2, c2, capacity, init_soc
											memset(aux_str, '\0', sizeof(aux_str));
											strncpy(aux_str, token + 6 + FPARAM_LEN*i, FPARAM_LEN);
											f_paramlist[i] = str2float(aux_str);
										}
										xSemaphoreTake( xParamMutex, portMAX_DELAY);
										xBatteryModuleParam.u8thermalmodel[cell_index] = model_type;
										xBatteryModuleParam.finitialtemp[cell_index] = f_paramlist[0];
										xBatteryModuleParam.u8thermalmodel[cell_index] = LUMPED_MODEL1;
										xSemaphoreGive(xParamMutex);
									}
								}
								else if (strncmp(header, HALLPARAM_ID, DEFLEN(HALLPARAM_ID)) == 0) // ntc parameters
								{
									for (uint8_t i = 0; i < HALLPARAM; i++)
									{	//curr min and curr max
										memset(aux_str, '\0', sizeof(aux_str));
										strncpy(aux_str, token + 2 + FPARAM_LEN*i, FPARAM_LEN);
										f_paramlist[i] = str2float(aux_str);
									}
									xSemaphoreTake( xParamMutex, portMAX_DELAY);
									xBatteryModuleParam.fhall_currmin = f_paramlist[0];
									xBatteryModuleParam.fhall_currmax = f_paramlist[1];
									xSemaphoreGive(xParamMutex);
									que_msg.u8code = HALLPARAM_CODE;
									que_msg.u16param = 0;
									xQueueSend( xQueue_tcpmsg, ( void * ) &que_msg, ( TickType_t ) 10);

								}
								else if (strncmp(header, NTCPARAM_ID, DEFLEN(NTCPARAM_ID)) == 0) // ntc parameters
								{
									for (uint8_t i = 0; i < NTCPARAM; i++)
									{	//r0, r1, c1, r2, c2, capacity, init_soc
										memset(aux_str, '\0', sizeof(aux_str));
										strncpy(aux_str, token + 2 + FPARAM_LEN*i, FPARAM_LEN);
										f_paramlist[i] = str2float(aux_str);
									}
									xSemaphoreTake( xParamMutex, portMAX_DELAY);
									xBatteryModuleParam.fntc_t0 = f_paramlist[0];
									xBatteryModuleParam.fntc_r0 = f_paramlist[1];
									xBatteryModuleParam.fntc_beta = f_paramlist[2];
									xBatteryModuleParam.fntc_rref = f_paramlist[3];
									xBatteryModuleParam.fntc_vref = f_paramlist[4];
									xSemaphoreGive(xParamMutex);
									que_msg.u8code = NTCPARAM_CODE;
									que_msg.u16param = 0;
									xQueueSend( xQueue_tcpmsg, ( void * ) &que_msg, ( TickType_t ) 10);
								}
								else if (strncmp(header, THERMPARAM_ID, DEFLEN(THERMPARAM_ID)) == 0) // ntc parameters
								{
									for (uint8_t i = 0; i < THERMPARAM; i++)
									{	//roomtemp, rcoretoair, rcoretosup, cap_therm
										memset(aux_str, '\0', sizeof(aux_str));
										strncpy(aux_str, token + 2 + FPARAM_LEN*i, FPARAM_LEN);
										f_paramlist[i] = str2float(aux_str);
									}
									xSemaphoreTake( xParamMutex, portMAX_DELAY);
									xBatteryModuleParam.froomtemp = f_paramlist[0];
									xBatteryModuleParam.fthres_coreair = f_paramlist[1];
									xBatteryModuleParam.fthres_coresurf = f_paramlist[2];
									xBatteryModuleParam.fthermcap = f_paramlist[3];
									xSemaphoreGive(xParamMutex);
									que_msg.u8code = THERMPARAM_CODE;
									que_msg.u16param = 0;
									xQueueSend( xQueue_tcpmsg, ( void * ) &que_msg, ( TickType_t ) 10);
								}
								else if (strncmp(header, MVOLTSET_ID, DEFLEN(MVOLTSET_ID)) == 0) // manual cell voltage set
								{
									que_msg.u8code = MVOLTSET_CODE;
									que_msg.u16param = 0;

									for (int i = 0; i < MAX_NUM_CELL; i++)
									{
										memset(aux_str, '\0', sizeof(aux_str));
										strncpy(aux_str, token + 2 + PARAM_LEN*i, PARAM_LEN);
										paramlist[i] = str2u16(aux_str);
									}
									//-------------------------------------------------------------------------------------------------
									sprintf(uart_buffer, "MSG- MANUAL CELL: %d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n\r", paramlist[0], paramlist[1], paramlist[2],
											paramlist[3], paramlist[4], paramlist[5], paramlist[6], paramlist[7]);
									send_uart(uart_buffer);
									//HAL_Delay(10);
									clear_uartbuffer();

									xSemaphoreTake( xreqOutMutex, portMAX_DELAY);
									for (int i = 0; i < MAX_NUM_CELL; i++)
									{
										reqModuleOutput.u16setvoltage[i]= paramlist[i];
									}
									xSemaphoreGive( xreqOutMutex);
									xQueueSend( xQueue_tcpmsg, ( void * ) &que_msg, ( TickType_t ) 10);
								}
								else if (strncmp(header, MCURRSET_ID, DEFLEN(MCURRSET_ID)) == 0) // manual module current set
								{
									que_msg.u8code = MCURRSET_CODE;
									que_msg.u16param = 0;
									paramlist[0] = str2u16(token + 2);
									//-------------------------------------------------------------------------------------------------
									sprintf(uart_buffer, "MSG- MANUAL CURR: %d\n\r", paramlist[0]);
									send_uart(uart_buffer);
									//HAL_Delay(10);
									clear_uartbuffer();

									xSemaphoreTake( xreqOutMutex, portMAX_DELAY);
									reqModuleOutput.u16setcurrent= paramlist[0];
									xSemaphoreGive(xreqOutMutex);
									xQueueSend( xQueue_tcpmsg, ( void * ) &que_msg, ( TickType_t ) 10);
								}
								else if (strncmp(header, MTEMPSET_ID, DEFLEN(MTEMPSET_ID)) == 0) // manual temperature set
								{
									que_msg.u8code = MTEMPSET_CODE;
									que_msg.u16param = 0;

									for (int i = 0; i < MAX_NUM_CELL; i++)
									{
										memset(aux_str, '\0', sizeof(aux_str));
										strncpy(aux_str, token + 2 + PARAM_LEN*i, PARAM_LEN);
										paramlist[i] = str2u16(aux_str);
									}
									//-------------------------------------------------------------------------------------------------
									sprintf(uart_buffer, "MSG- MANUAL TEMP: %d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n\r", paramlist[0], paramlist[1], paramlist[2],
											paramlist[3], paramlist[4], paramlist[5], paramlist[6], paramlist[7]);
									send_uart(uart_buffer);
									//HAL_Delay(10);
									clear_uartbuffer();
									xSemaphoreTake( xreqOutMutex, portMAX_DELAY);
									for (int i = 0; i < MAX_NUM_CELL; i++)
									{
										reqModuleOutput.u16settemperature[i]= paramlist[i];
									}
									xSemaphoreGive( xreqOutMutex);
									xQueueSend( xQueue_tcpmsg, ( void * ) &que_msg, ( TickType_t ) 10);
								}
								token = strtok(NULL, separator);
						   }
						}
						while (netbuf_next(buf)>0);
						netbuf_delete(buf);
						memset(msg, '\0', sizeof(msg));
					}

					/* Close connection and discard connection identifier. */
					netconn_close(newconn);
					netconn_delete(newconn);
				}
			}
		}
		else
		{
			netconn_delete(conn);
		}
	}
}

