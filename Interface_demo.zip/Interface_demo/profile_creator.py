filename =  "papaprofile.txt"

startV  = 3.700
maxV    = 4.500
minV    = 2.500
dV      = 0.05

startI  = 0.0
maxI    = 80.0
minI    = -80.0
dI      = 2.0

startT  = 25.0
maxT    = 75.0
minT    = -30
dT      = 1.0

dt      = 1.0

v_vect = []
i_vect = []
t_vect = []

#profilo tensione singola cella
for i in range (round((maxV - startV)/dV)):
    value = startV + i* dV
    v_vect.append(f"{value:.3f}")
for i in range (round((maxV - minV)/dV)):
    value = maxV - i* dV
    v_vect.append(f"{value:.3f}")
for i in range (round((startV - minV)/dV)+1):
    value = minV + i* dV
    v_vect.append(f"{value:.3f}")

i_vect = []
#profilo corrente
for i in range (round((maxI - startI)/dI)):
    value = startI + i* dI
    i_vect.append(f"{value:.3f}")
for i in range (round((maxI - minI)/dI)):
    value = maxI - i* dI
    i_vect.append(f"{value:.3f}")
for i in range (round((startI - minI)/dI)+1):
    value = minI + i* dI
    i_vect.append(f"{value:.3f}")

T_vect = []
#profilo temperatura singola cella
for i in range (round((maxT - startT)/dT)):
    value = startT + i* dT
    T_vect.append(f"{value:.3f}")
for i in range (round((maxT - minT)/dT)):
    value = maxT - i* dT
    T_vect.append(f"{value:.3f}")
for i in range (round((startT - minT)/dT)+1):
    value = minT + i* dT
    T_vect.append(f"{value:.3f}")

fp = open(filename,'w+')
fp.write("Time\tModule\tTarget_Type\tIndex\tValue\n")
#tensione, ripetizione sulle tensione di celle
for j in range(4):
    for i in v_vect:
        line = f"{dt:.1f}" + '\t0\tV\t' + str(j) + '\t' + i + '\n'
        fp.write(line)

#corrente
for i in i_vect:
    line = f"{dt:.1f}" + '\t0\tI\t0\t' + i + '\n'
    fp.write(line)

#temperatura, ripetizione sulle tensione di celle
for j in range(4):
    for i in T_vect:
        line = f"{dt:.1f}" + '\t0\tT\t' + str(j) + '\t' + i + '\n'
        fp.write(line)

fp.close()

