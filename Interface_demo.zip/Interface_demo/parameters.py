# DO NOT USE INDENTATION!!! 
# OCV-SOC Look-Up Table: 11 values relative to 0, 10, 20, ...., 100 % of SoC, voltages as 0.1mV
OCV_SOC_1 = [27000, 29000, 30000, 32000, 33000, 35000, 36000, 37000, 39000, 40500, 42000]
OCV_SOC_2 = [27000, 29000, 30000, 32000, 33000, 35000, 36000, 37000, 39000, 40500, 42000]
#Internal resistance values (ohms)
R0value_1 = 0.003
R0value_2 = 0.008

#RC branches, R(Ohm) C(F)
R1value_1 = 0.003
R1value_2 = 0.023
C1value_1 = 2000
C1value_2 = 1000

#RC branches, R(Ohm) C(F)
R2value_1 = 0.007
R2value_2 = 0.01
C2value_1 = 15800000
C2value_2 = 1000000

#Nominal Capacity (Ah)
NominalCapacity_1 = 3
NominalCapacity_2 = 512

#InitialSoc (between 0 and 1)
InitialSoc_1 = 0.5
InitialSoc_2 = 0.2

#Initial temperature of the cell [K]
InitTemp_1 = 25 + (273.15)
InitTemp_2 = 55 + (273.15)

#TEMPERATURE CONVERSION LAW
beta = 3435
vref = 3.3 #Vref value of NTC 
r0 = 10000.0
T0 = 25.0 + 273.15 
rref = 10000.0

#Current Conversion LAW
curr_min = -75
curr_max = 75
half_val = 32768
sens = 349.96 #code/A  
#-5A ; 5A  ---> -12V ; 12V --> 0, 65535  

#Thermal parameters
res_coretoair = 67.4875     #[K/W]
res_coretosup =  29.6123    #[K/W]
cap_therm = 21.4444         #[J/K]
room_temp = 25.0 + 273.15   #[K]

#*********************************************
#Calibration parameters
dac_gain1 = 1.002004008
dac_gain2 = 0.996810207
dac_gain3 = 0.994035785
dac_gain4 = 0.995619275
dac_gain5 = 1.0
dac_gain6 = 1.0
dac_gain7 = 1.0
dac_gain8 = 1.0

dac_offset1 = -13
dac_offset2 = -73
dac_offset3 = 156
dac_offset4 = -172
dac_offset5 = 0.0
dac_offset6 = 0.0
dac_offset7 = 0.0
dac_offset8 = 0.0

adc_gainV1 = 1.0194927
adc_gainV2 = 1.020366516
adc_gainV3 = 1.018952517
adc_gainV4 = 1.017956757
adc_gainV5 = 1.0
adc_gainV6 = 1.0
adc_gainV7 = 1.0
adc_gainV8 = 1.0

adc_offsetV1 = 21
adc_offsetV2 = 14
adc_offsetV3 = 13
adc_offsetV4 = 14
adc_offsetV5 = 0.0
adc_offsetV6 = 0.0
adc_offsetV7 = 0.0
adc_offsetV8 = 0.0

adc_gainI1 = 1.0
adc_gainI2 = 1.0
adc_gainI3 = 1.0
adc_gainI4 = 1.0
adc_gainI5 = 1.0
adc_gainI6 = 1.0
adc_gainI7 = 1.0
adc_gainI8 = 1.0

adc_offsetI1 = 0.0
adc_offsetI2 = 0.0
adc_offsetI3 = 0.0
adc_offsetI4 = 0.0
adc_offsetI5 = 0.0
adc_offsetI6 = 0.0
adc_offsetI7 = 0.0
adc_offsetI8 = 0.0

dac_gainHn = 1.006036217
dac_gainHp = 1.006545689
dac_offsetH = -102
adc_gainH = 1.0
adc_offsetH = 7.0

################ INITIAL VALUES
initV = 3.3
initT = 25.0
initI = 0