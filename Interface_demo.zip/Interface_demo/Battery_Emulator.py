from PyQt5 import QtGui, QtCore, QtWidgets
from window import Ui_MainWindow
from moduleWorker import COMWorker, COM
from decoder import msgDecoder 
from datetime import datetime  
import sys
import os
import socket
import copy
import math
import struct
#import serial
import parameters as param 
import defines as dfn



class Main(QtWidgets.QMainWindow):
    def __init__(self):       
        QtWidgets.QMainWindow.__init__(self)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.max_cell_module = 8

        #default values of button
        self.ui.pathLabel.setText(dfn.default_config_path)

        #default values of emulator assembly
        self.max_module = dfn.max_module
        self.number_of_modules = 0
        self.configdone = False
        self.currentprofileloaded = False

        #timer for automatic mode
        self.test_timer = QtCore.QTimer(self)
        self.test_timer.timeout.connect(self.ModelManager)
        self.test_index = 0 
        self.last_run = 0

        #timer for Manual profile mode
        self.profile_timer = QtCore.QTimer(self)
        self.profile_timer.timeout.connect(self.ProfileManager)
        self.profile_index = 0 
        self.profilelast_run = 0

        #timer for periodic logging
        self.log_timer = QtCore.QTimer(self)
        self.log_timer.timeout.connect(self.logTimerTimeout)
        self.log_file = None
        self.log_mode = 'auto'

        #FOR multimodule visualization
        self.AutoVisualModule = 0
        self.ManualVisualModule = 0

        self.chModule = 0
        self.chType = 0
        self.chElem = 0
        self.settoallsub = 0
        self.settoallmod = 0

        #connect button with their called function
        self.ui.LoadParamButton.clicked.connect(self.LoadParamFile)
        self.ui.ReadParamButton.clicked.connect(self.ReadParamFile)
        self.ui.connectButton.clicked.connect(self.connectToModules)
        self.ui.loadCurrentButton.clicked.connect(self.LoadCurrentFile)
        self.ui.readCurrentButton.clicked.connect(self.ReadCurrentFile)     
        self.ui.configModuleButton.clicked.connect(self.configModel)
        self.ui.runModelButton.clicked.connect(self.runModel)
        self.ui.calibrationButton.clicked.connect(self.calibrate)
        self.ui.stopModelButton.clicked.connect(self.stopModel)
        self.ui.restoreButton.clicked.connect(self.restoreModel)
        self.ui.manualLogStartButton.clicked.connect(self.logTimerStart) 
        self.ui.manualLogStopButton.clicked.connect(self.logTimerStop)
        self.ui.setDefaultButton.clicked.connect(self.set_initstatus)
        self.ui.startManProfButton.clicked.connect(self.startManProfile)
        self.ui.stopManProfButton.clicked.connect(self.stopManProfile)

        self.ui.AModselCombo.currentIndexChanged.connect(self.onAutoModulechange)
        self.ui.MModselCombo.currentIndexChanged.connect(self.onManualModulechange)
        self.ui.ChModuleCombo.currentIndexChanged.connect(self.onChModulechange)
        self.ui.ChTypeCombo.currentIndexChanged.connect(self.onChTypechange)
        self.ui.ChElementCombo.currentIndexChanged.connect(self.onChElementchange)
        self.ui.SetToAllSubCheck.stateChanged.connect(self.onSetToAllSubchange)
        self.ui.SetToAllModCheck.stateChanged.connect(self.onSetToAllModchange)
        self.ui.setValueButton.clicked.connect(self.SetValueClick)


        #Hide optional tabs
        self.ui.M0Label.setHidden(True)
        self.ui.M1Label.setHidden(True)
        self.ui.M2Label.setHidden(True)
        self.ui.M3Label.setHidden(True)
        self.ui.M4Label.setHidden(True)
        self.ui.M5Label.setHidden(True)
        self.ui.M6Label.setHidden(True)
        self.ui.M7Label.setHidden(True)
        
        self.ui.M0ncellLabel.setHidden(True)
        self.ui.M1ncellLabel.setHidden(True)
        self.ui.M2ncellLabel.setHidden(True)
        self.ui.M3ncellLabel.setHidden(True)
        self.ui.M4ncellLabel.setHidden(True)
        self.ui.M5ncellLabel.setHidden(True)
        self.ui.M6ncellLabel.setHidden(True)
        self.ui.M7ncellLabel.setHidden(True)
        
        self.ui.M0currCheck.setHidden(True)
        self.ui.M1currCheck.setHidden(True)
        self.ui.M2currCheck.setHidden(True)
        self.ui.M3currCheck.setHidden(True)
        self.ui.M4currCheck.setHidden(True)
        self.ui.M5currCheck.setHidden(True)
        self.ui.M6currCheck.setHidden(True)
        self.ui.M7currCheck.setHidden(True)
        
        self.ui.M0tempCheck.setHidden(True)
        self.ui.M1tempCheck.setHidden(True)
        self.ui.M2tempCheck.setHidden(True)
        self.ui.M3tempCheck.setHidden(True)
        self.ui.M4tempCheck.setHidden(True)
        self.ui.M5tempCheck.setHidden(True)
        self.ui.M6tempCheck.setHidden(True)
        self.ui.M7tempCheck.setHidden(True)
        
        self.ui.M0ipLabel.setHidden(True)
        self.ui.M1ipLabel.setHidden(True)
        self.ui.M2ipLabel.setHidden(True)
        self.ui.M3ipLabel.setHidden(True)
        self.ui.M4ipLabel.setHidden(True)
        self.ui.M5ipLabel.setHidden(True)
        self.ui.M6ipLabel.setHidden(True)
        self.ui.M7ipLabel.setHidden(True)
        
       
        self.ui.configModuleButton.setEnabled(False)
        self.ui.calibrationButton.setEnabled(False)
        self.ui.runModelButton.setEnabled(False)
        self.ui.calibrationButton.setEnabled(False)
        self.ui.connectButton.setEnabled(False)
        self.ui.stopModelButton.setEnabled(False)
        self.ui.restoreButton.setEnabled(False)
        self.ui.manualLogStopButton.setEnabled(False)
        self.ui.setDefaultButton.setEnabled(False)
        self.ui.startManProfButton.setEnabled(False)
        self.ui.stopManProfButton.setEnabled(False)
        
    def SetValueClick(self):
        data_str = self.ui.setValueText.text()
        _data = data_str.replace(",", ".") #if , is used as decimal separator it is corrected
        if(self.chType == 0): #cell voltage
            try:
                data_hex = self.convertCellToCode(_data)
                msgid = COM['manualCellset']
            except: 
                #TODO mettere msgbox
                print("dato non valido")
                return
        elif(self.chType == 1): #battery current
            try:
                data_hex = self.convertCurrToCode(_data)
                msgid = COM['manualCurrset']
            except: 
                #TODO mettere msgbox
                print("dato non valido curr")
                return
        elif(self.chType == 2): #temperature 
            try:
                data_hex = self.convertTempToCode(_data)
                msgid = COM['manualTempset']
            except: 
                #TODO mettere msgbox
                print("dato non valido temp")
                return
        if(self.settoallsub and self.settoallmod): #all the submodules of all modules has to changed
            new_value = []
            for i in range(len(self.battery_emulator_manual[self.chModule][self.chType])):
                new_value.append(data_hex)
            for i in range(self.number_of_modules):
                self.battery_emulator_manual[i][self.chType] = copy.deepcopy(new_value)
        elif(self.settoallsub): #all the submodules of the given module has to be changed
            new_value = []
            for i in range(len(self.battery_emulator_manual[self.chModule][self.chType])):
                new_value.append(data_hex)
            self.battery_emulator_manual[self.chModule][self.chType] = copy.deepcopy(new_value)
        elif(self.settoallmod):
            for i in range (self.number_of_modules):
                self.battery_emulator_manual[i][self.chType][self.chElem] = data_hex
        else:
            self.battery_emulator_manual[self.chModule][self.chType][self.chElem] = data_hex
        if(self.settoallmod):
            for i in range(self.number_of_modules):
                msg = msgid
                for j in range(len(self.battery_emulator_manual[i][self.chType])):
                    msg +=  self.battery_emulator_manual[i][self.chType][j]
                msg += COM['stop']
                getattr(self,'moduleWorker' + str(i)).send_message(msg)
        else:
            msg = msgid
            for j in range(len(self.battery_emulator_manual[self.chModule][self.chType])):
                msg +=  self.battery_emulator_manual[self.chModule][self.chType][j]
            msg += COM['stop']
            getattr(self,'moduleWorker' + str(self.chModule)).send_message(msg)

    def convertCellToCode(self, data):
        data = float(data)
        if(data < 0 or data >= 5):
            raise Exception("")
        else:
            code = int((data/5.0)*65536.0)
            code = f"{code:04X}"
            return code

    def convertCurrToCode(self, data):
        data = float(data)
        if(data <= param.curr_min or data >= param.curr_max):
            raise Exception("")
        else:
            """ CODICE PER SENSORE +-12V 
            code = int((data - param.curr_min)/(param.curr_max - param.curr_min)*65536.0)
            code = f"{code:04X}"
            """
            #CODICE SENSORE 0-5V
            code = param.half_val + round(data*param.sens)  
            code = f"{code:04X}"
            return code    

    def convertTempToCode(self, data): 
        data = float(data) #celsius
        if(data < -40 or data > 125):
            raise Exception("Valori non validi")
        else:
            data = data + 273.15 #temperature in kelvin
            r = param.r0 * math.exp(param.beta*((1.0/data)-(1/param.T0)))
            vout = param.vref * r /(param.rref + r)
            code = int((vout/5.0)*4096.0)
            code = f"{code:04X}"
            return code    

    def onSetToAllSubchange(self, value):
        self.settoallsub = bool(value)

    def onSetToAllModchange(self, value):
        self.settoallmod = bool(value)

    def onAutoModulechange(self):
        self.AutoVisualModule = self.ui.AModselCombo.currentIndex()
        for i in range(self.max_cell_module):
            if(i < self.battery_emulator[self.AutoVisualModule].cell_num):
                getattr(self.ui, 'ACellLabel' + str(i)).setHidden(False)
                getattr(self.ui, 'ACellSetLabel' + str(i)).setHidden(False)
                getattr(self.ui, 'ACellReadLabel' + str(i)).setHidden(False)
                getattr(self.ui, 'ACellCurrLabel' + str(i)).setHidden(False)
                getattr(self.ui, 'ATempSetLabel' + str(i)).setHidden(False)
                getattr(self.ui, 'ATempReadLabel' + str(i)).setHidden(False)
                getattr(self.ui, 'ACellSetLabel' + str(i)).setText(self.bem_auto_data[self.AutoVisualModule].cell_set[i])
                getattr(self.ui, 'ACellReadLabel' + str(i)).setText(self.bem_auto_data[self.AutoVisualModule].cell_read[i])
                getattr(self.ui, 'ACellCurrLabel' + str(i)).setText(self.bem_auto_data[self.AutoVisualModule].cell_curr[i])
                getattr(self.ui, 'ATempSetLabel' + str(i)).setText(self.bem_auto_data[self.AutoVisualModule].temp_set[i])
                getattr(self.ui, 'ATempReadLabel' + str(i)).setText(self.bem_auto_data[self.AutoVisualModule].temp_read[i])
            else:
                getattr(self.ui, 'ACellLabel' + str(i)).setHidden(True)
                getattr(self.ui, 'ACellSetLabel' + str(i)).setHidden(True)
                getattr(self.ui, 'ACellReadLabel' + str(i)).setHidden(True)
                getattr(self.ui, 'ACellCurrLabel' + str(i)).setHidden(True)
                getattr(self.ui, 'ATempSetLabel' + str(i)).setHidden(True)
                getattr(self.ui, 'ATempReadLabel' + str(i)).setHidden(True)

    def onManualModulechange(self):
        self.ManualVisualModule = self.ui.MModselCombo.currentIndex()
        for i in range(self.max_cell_module):
            if(i < self.battery_emulator[self.ManualVisualModule].cell_num):
                getattr(self.ui, 'MCellLabel' + str(i)).setHidden(False)
                getattr(self.ui, 'MCellSetLabel' + str(i)).setHidden(False)
                getattr(self.ui, 'MCellReadLabel' + str(i)).setHidden(False)
                getattr(self.ui, 'MCellCurrLabel' + str(i)).setHidden(False)
                getattr(self.ui, 'MCellSetLabel' + str(i)).setText(self.bem_manual_data[self.ManualVisualModule].cell_set[i])
                getattr(self.ui, 'MCellReadLabel' + str(i)).setText(self.bem_manual_data[self.ManualVisualModule].cell_read[i])
                getattr(self.ui, 'MCellCurrLabel' + str(i)).setText(self.bem_manual_data[self.ManualVisualModule].cell_curr[i])
            else:
                getattr(self.ui, 'MCellLabel' + str(i)).setHidden(True)
                getattr(self.ui, 'MCellSetLabel' + str(i)).setHidden(True)
                getattr(self.ui, 'MCellReadLabel' + str(i)).setHidden(True)
                getattr(self.ui, 'MCellCurrLabel' + str(i)).setHidden(True)

        if(self.battery_emulator[self.ManualVisualModule].temp_board):
            self.ui.MTempBox.setHidden(False)
            for i in range(self.max_cell_module):
                getattr(self.ui, 'MTempSetLabel' + str(i)).setText(self.bem_manual_data[self.ManualVisualModule].temp_set[i])
                getattr(self.ui, 'MTempReadLabel' + str(i)).setText(self.bem_manual_data[self.ManualVisualModule].temp_read[i])
        else:
            self.ui.MTempBox.setHidden(True)

        if(self.battery_emulator[self.ManualVisualModule].curr_board):
            self.ui.MCurrBox.setHidden(False)
            getattr(self.ui, 'MCurrSetLabel').setText(self.bem_manual_data[self.ManualVisualModule].curr_set)
            getattr(self.ui, 'MCurrReadLabel').setText(self.bem_manual_data[self.ManualVisualModule].curr_read)
        else:
            self.ui.MCurrBox.setHidden(True)

    def onChModulechange (self):
        self.chModule = self.ui.ChModuleCombo.currentIndex()
        self.ui.ChTypeCombo.clear()
        if(self.battery_emulator[self.chModule].cell_num):
            self.ui.ChTypeCombo.addItem("Cell Submodule")
        if(self.battery_emulator[self.chModule].curr_board):
            self.ui.ChTypeCombo.addItem("Current Submodule")
        if(self.battery_emulator[self.chModule].temp_board):
            self.ui.ChTypeCombo.addItem("Temperature Submodule")

    def onChTypechange(self):
        seltype = self.ui.ChTypeCombo.currentText()
        self.ui.ChElementCombo.clear()
        if(seltype.startswith("Ce")):
            self.chType = 0
        elif(seltype.startswith("Cu")):
            self.chType = 1
        else: 
            self.chType = 2
        if (self.chType == 0):
            for i in range(self.battery_emulator[self.chModule].cell_num):
                self.ui.ChElementCombo.addItem("Cell Voltage "+str(i))
                self.ui.UnitLabel.setText("[V]")
        elif(self.chType == 1):
            self.ui.ChElementCombo.addItem("Current")
            self.ui.UnitLabel.setText("[A]")
        if (self.chType == 2):
            for i in range(self.max_cell_module):
                self.ui.ChElementCombo.addItem("Temperature "+str(i))
                self.ui.UnitLabel.setText("[°C]")

    def onChElementchange(self):
        self.chElem = self.ui.ChElementCombo.currentIndex()

    def stopModel(self):
        self.ui.stopModelButton.setEnabled(False)
        self.ui.restoreButton.setEnabled(True)
        self.ui.runModelButton.setEnabled(True)
        self.ui.setDefaultButton.setEnabled(True)
        self.ui.startManProfButton.setEnabled(True)
        msg = COM['start'] + COM['mode'] + f"{0:04X}" + COM['stop'] #stop the auto run of the model
        for i in range(self.number_of_modules):
            getattr(self,'moduleWorker' + str(i)).send_message(msg)
        self.test_timer.stop()
        self.log_timer.stop()

    def stopManProfile(self):
        self.ui.runModelButton.setEnabled(True)
        self.ui.setDefaultButton.setEnabled(True)
        self.ui.startManProfButton.setEnabled(True)
        self.ui.stopManProfButton.setEnabled(False)
        self.profile_timer.stop()

    def restoreModel(self):
        for i in range(self.number_of_modules):
            config_str = COM['start'] + COM['restoreECM']
            #for j in range(self.battery_emulator[i].cell_num):
                #config_str += f"{self.battery_emulator[i].InitialSoc[j]:04X}" 
            config_str += COM['stop']
            getattr(self,'moduleWorker' + str(i)).send_message(config_str)

    def ProfileManager(self):
        if (self.profilelast_run == 0):
            _value = []
            for j in range(len(self.profile_value)):
                _value.append(self.profile_value[j].replace(",", ".")) #if , is used as decimal separator it is corrected
            print(self.profile_targetType[self.profile_index])
            if(self.profile_targetType[self.profile_index] == 'V'): #cell voltage
                try:
                    data_hex = self.convertCellToCode(_value[self.profile_index])
                    msgid = COM['manualCellset']
                    type = 0 #tensione di cella 
                except: 
                    #TODO mettere msgbox
                    print("dato non valido")
                    return
            elif(self.profile_targetType[self.profile_index] == 'I'): #battery current
                try:
                    data_hex = self.convertCurrToCode(_value[self.profile_index])
                    msgid = COM['manualCurrset']
                    type = 1 #corrente 
                except: 
                    #TODO mettere msgbox
                    print("dato non valido curr")
                    return
            elif(self.profile_targetType[self.profile_index] == 'T'): #temperature 
                print("visto")
                try:
                    data_hex = self.convertTempToCode(_value[self.profile_index])
                    msgid = COM['manualTempset']
                    type = 2 #temperatura di cella 
                except: 
                    #TODO mettere msgbox
                    print("dato non valido temp")
                    return
            self.battery_emulator_manual[self.targ_module[self.profile_index]][type][self.profile_targetIndex[self.profile_index]] = data_hex
            msg = msgid
            for j in range(len(self.battery_emulator_manual[self.targ_module[self.profile_index]][type])):
                msg +=  self.battery_emulator_manual[self.targ_module[self.profile_index]][type][j]
            msg += COM['stop']
            getattr(self,'moduleWorker' + str(self.targ_module[self.profile_index])).send_message(msg)
            self.profile_timer.start(self.profile_time[self.profile_index])
            self.profile_index += 1
            if (self.profile_index >= len(self.profile_time)):
                self.profilelast_run = 1
        else:
            self.profile_timer.stop()
            self.ui.stopModelButton.setEnabled(False)
            self.ui.restoreButton.setEnabled(True)
            self.ui.runModelButton.setEnabled(True)
            self.ui.setDefaultButton.setEnabled(True)
            self.ui.startManProfButton.setEnabled(True)
            self.ui.stopManProfButton.setEnabled(False)

    def ModelManager(self):
        if (self.last_run == 0):
            msg = COM['start'] + COM['modelCurr'] + f"{self.test_current[self.test_index]:04X}" + COM['stop']
            for i in range(self.number_of_modules):
                getattr(self,'moduleWorker' + str(i)).send_message(msg)
            self.test_timer.start(self.test_time[self.test_index])
            self.test_index += 1
            if (self.test_index >= len(self.test_time)):
                self.last_run = 1
        else:
            msg = COM['start'] + COM['mode'] + f"{0:04X}" + COM['stop'] #stop the auto run of the model
            for i in range(self.number_of_modules):
                getattr(self,'moduleWorker' + str(i)).send_message(msg)
            self.test_timer.stop()
            self.log_timer.stop()
            self.ui.stopModelButton.setEnabled(False)
            self.ui.restoreButton.setEnabled(True)
            self.ui.runModelButton.setEnabled(True)
            self.ui.setDefaultButton.setEnabled(True)
            self.ui.startManProfButton.setEnabled(True)
    
    def logTimerStart(self):
        self.ui.manualLogStartButton.setEnabled(False)
        self.ui.manualLogStopButton.setEnabled(True)
        self.log_mode = 'manual'
        now = datetime.now() # current date and time
        filename = now.strftime("%Y_%m_%d__%H_%M_%S")
        for i in range(self.number_of_modules):
            filename = "logManual_M" + str(i) + "_" + filename + '.txt'
            filep = os.path.join('log',filename)
            setattr(self, 'logfile' + str(i),open(filep, 'w'))
            header = "Date\tTime"
            for j in range(self.battery_emulator[i].cell_num):
                header += '\tVset' + str(j) + '[V]' +  '\tVread' + str(j) + '[V]' + '\tIcell' + str(j) + '[A]'
            if(self.battery_emulator[i].curr_board):
                header += '\tImodset[A]\tImodread[A]' 
            if(self.battery_emulator[i].temp_board):
                header += '\tT0set[degC]\tT0read[degC]\tT1set[degC]\tT1read[degC]\tT2set[degC]\tT2read[degC]\tT3set[degC]\tT3read[degC]'
                header += '\tT4set[degC]\tT4read[degC]\tT5set[degC]\tT5read[degC]\tT6set[degC]\tT6read[degC]\tT7set[degC]\tT7read[degC]'
            header += '\n'
            getattr(self, 'logfile'+str(i)).write(header)
        self.log_timer.start(dfn.LOG_PERIOD)#periodo di log (ms)

    def logTimerStop(self):
        self.ui.manualLogStartButton.setEnabled(True)
        self.ui.manualLogStopButton.setEnabled(False)
        self.log_timer.stop()
        for i in range(self.number_of_modules):
            getattr(self,'logfile'+str(i)).close()

    def logTimerTimeout(self):
        msg = COM['datarequest']+COM['stop']
        for i in range(self.number_of_modules):
            getattr(self,'moduleWorker' + str(i)).send_message(msg)
        self.log_timer.start(dfn.LOG_PERIOD)         

    def LoadParamFile(self):
        dialog_window = QtWidgets.QFileDialog(caption = "Chose the configuration file to read")
        dialog_window.setFileMode(QtWidgets.QFileDialog.ExistingFile)
        dialog_window.setNameFilter("Text files (*.txt)")
        #filenames = QtCore.QStringList()
		
        if(dialog_window.exec_()): #user selected "open file"; Dialog close or cancel return 0
            filename = dialog_window.selectedFiles() #returns a list of selected files; the first one is processed
            self.ui.pathLabel.setText(filename[0])
        
    def ReadParamFile(self):
        config_path = os.path.join('',self.ui.pathLabel.text())
        if(os.path.isfile(config_path)):
            filep = open(config_path)
            lines = filep.readlines()
            filep.close()
            module_line_index = [] #list of line index of '@MOUDULE_INFO_' in config files
            expected_num_modules = 100 #expected number of module
            module_found = 0 
            self.ipaddress = []
            #search th
            if(lines[0].startswith('#--BATTERY_EMULATOR_CONFIGURATION_FILE--#')):   #file valido
                for index,line in enumerate(lines):
                    line = line.replace(" ", "")
                    if (line.startswith('@NUMBER_OF_MODULES')):
                        part = line.split(':')
                        expected_num_modules = int(part[1]) 
                    if (line.startswith('@MODULE_INFO_')):
                        module_line_index.append(index)
                        module_found += 1
            else: #il file non è un file valido
                #TODO mettere la msgbox con errore
                print("Errore1")

            if(expected_num_modules != module_found ): #il numero di moduli che mi aspetto è maggiore di quelli per cui ho dato informazioni
                #TODO mettere la msgbox con errore
                print("Errore2")
            #for i in module_line_index:     

            self.battery_emulator = []
            for i in module_line_index:
                part = lines[i+1].split(':') #IP address
                self.ipaddress.append(part[1].strip())
                part = lines[i+2].split(':') #number of cell
                cell_num = int(part[1])
                part = lines[i+3].split(':') #number of temperature board
                temp_board = bool(int(part[1]))
                part = lines[i+4].split(':') #number of current board
                _part = part[1].split(';') #_part[0] = curr board
                curr_board = bool(int(_part[0].strip()))

                dac_gainHn = float(param.dac_gainHn)
                dac_gainHp = float(param.dac_gainHp)
                dac_offsetH = float(param.dac_offsetH)
                adc_gainH = float(param.adc_gainH)
                adc_offsetH = float(param.adc_offsetH)

                ECM_Model_type = []
                THER_Model_type = []
                OCV_SOC_LUT = []
                R0 = []
                R1 = []
                C1 = []
                R2 = []
                C2 = []
                NominalCapacity = []
                InitialSoc = []
                InitialTemperature = []
                dac_gain = []
                dac_offset = []
                adc_gainV = []
                adc_offsetV = []
                adc_gainI = []
                adc_offsetI = []

                for k in range(cell_num):
                    data = lines[i+5+k].split(':') #split header and data
                    _data = data[1].split(';')      #_data[0] contains EMC model, _data[1] Thermal model, _data[2] Nominal capacity, _data [3] initial SoC
                    ECM_Model_param = _data[0].split('(')
                    ECM_Model_type.append(ECM_Model_param[0].strip())
                    ECM_Model_param = ECM_Model_param[1].replace(")", "")
                    ECM_Model_param = ECM_Model_param.split(',')  #[0] OCV-SOC, [1]R0, [2]R1, [3]C1, [4]R2, [5]C2
                    if(ECM_Model_type[-1] == 'No_ECM_Model'): 
                        OCV_SOC_LUT.append([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
                        R0.append(0)
                        R1.append(0)
                        C1.append(0)
                        R2.append(0)
                        C2.append(0)
                    if(ECM_Model_type[-1] == 'OCV_SOC_Model'): 
                        OCV_SOC_LUT.append(getattr(param, ECM_Model_param[0]))
                        R0.append(0)
                        R1.append(0)
                        C1.append(0)
                        R2.append(0)
                        C2.append(0)
                    if(ECM_Model_type[-1] == 'Rint_Model'): 
                        OCV_SOC_LUT.append(getattr(param, ECM_Model_param[0]))
                        R0.append(getattr(param, ECM_Model_param[1].strip()))
                        R1.append(0)
                        C1.append(0)
                        R2.append(0)
                        C2.append(0)
                    if(ECM_Model_type[-1] == '1RC_Model'): 
                        OCV_SOC_LUT.append(getattr(param, ECM_Model_param[0]))
                        R0.append(getattr(param, ECM_Model_param[1].strip()))
                        R1.append(getattr(param, ECM_Model_param[2].strip()))
                        C1.append(getattr(param, ECM_Model_param[3].strip()))
                        R2.append(0)
                        C2.append(0)
                    if(ECM_Model_type[-1] == '2RC_Model'): 
                        OCV_SOC_LUT.append(getattr(param, ECM_Model_param[0]))
                        R0.append(getattr(param, ECM_Model_param[1].strip()))
                        R1.append(getattr(param, ECM_Model_param[2].strip()))
                        C1.append(getattr(param, ECM_Model_param[3].strip()))
                        R2.append(getattr(param, ECM_Model_param[4].strip()))
                        C2.append(getattr(param, ECM_Model_param[5].strip()))
                    THER_Model_param = _data[1].split('(')
                    THER_Model_type.append(THER_Model_param[0].strip())
                    if (THER_Model_type[-1] == 'Lumped_Thermal_Model'):
                        InitialTemperature.append(getattr(param, THER_Model_param[1].replace(")", "")))
                    else:
                        InitialTemperature.append(0)
                    NominalCapacity.append(getattr(param, _data[2].strip()))
                    InitialSoc.append(getattr(param, _data[3].strip()))
                    dac_gain.append(getattr(param, "dac_gain" + str(k+1) ))
                    dac_offset.append(getattr(param, "dac_offset" + str(k+1)))
                    adc_gainV.append(getattr(param, "adc_gainV" + str(k+1)))
                    adc_offsetV.append(getattr(param, "adc_offsetV" + str(k+1) ))
                    adc_gainI.append(getattr(param, "adc_gainI" + str(k+1)))
                    adc_offsetI.append(getattr(param,"adc_offsetI" + str(k+1) ))

                if (cell_num != self.max_cell_module):
                    missing_cell = self.max_cell_module - cell_num
                    for j in range (missing_cell):
                        ECM_Model_type.append("")
                        OCV_SOC_LUT.append(0)
                        R0.append(0)
                        R1.append(0)
                        C1.append(0)
                        R2.append(0)
                        C2.append(0)
                        NominalCapacity.append(0) 
                        InitialSoc.append(0)
                        dac_gain.append(1.0)
                        dac_offset.append(0.0)
                        adc_gainV.append(1.0)
                        adc_offsetV.append(0.0)
                        adc_gainI.append(1.0)
                        adc_offsetI.append(0.0)
                
                self.battery_emulator.append(dfn.Battery_Module(cell_num, temp_board,curr_board, dac_gainHn, dac_gainHp, dac_offsetH, adc_gainH, adc_offsetH,
                    ECM_Model_type, THER_Model_type, OCV_SOC_LUT, R0, R1, C1, R2, C2, InitialTemperature, NominalCapacity, InitialSoc, dac_gain, dac_offset, adc_gainV, adc_offsetV, adc_gainI, adc_offsetI ))

            self.number_of_modules = len(self.battery_emulator)
            for i in range(self.number_of_modules):
                getattr(self.ui, 'M' + str(i)+'Label').setHidden(False)
                getattr(self.ui, 'M' + str(i)+'ncellLabel').setHidden(False)
                getattr(self.ui, 'M' + str(i)+'ncellLabel').setText(str(self.battery_emulator[i].cell_num))
                getattr(self.ui, 'M' + str(i)+'currCheck').setHidden(False)
                getattr(self.ui, 'M' + str(i)+'currCheck').setChecked(self.battery_emulator[i].curr_board)
                getattr(self.ui, 'M' + str(i)+'currCheck').setEnabled(False)
                getattr(self.ui, 'M' + str(i)+'tempCheck').setHidden(False)
                getattr(self.ui, 'M' + str(i)+'tempCheck').setChecked(self.battery_emulator[i].temp_board)
                getattr(self.ui, 'M' + str(i)+'tempCheck').setEnabled(False)
                getattr(self.ui, 'M' + str(i)+'ipLabel').setHidden(False)
                getattr(self.ui, 'M' + str(i)+'ipLabel').setText(self.ipaddress[i])

            #create the structure for saving the manual data to be set
            self.battery_emulator_manual = [] #is an array of module in which [0] there is the cell voltage code array, in [1] the current and in [2] the temperature code array
            module_default = []
            cell_default = []
            temp_default = []
            curr_default = []
            for i in range (self.max_cell_module):
                cell_default.append("8000")
                temp_default.append("0800")
            curr_default.append("8000")
            module_default.append(cell_default.copy()) #default value for the cell voltage
            module_default.append(curr_default.copy()) #defalut value for the current
            module_default.append(temp_default.copy()) #default value for the cell voltage
            for i in range(self.number_of_modules):
                self.battery_emulator_manual.append(copy.deepcopy(module_default))

            #create structures for data saving
            self.bem_manual_data = []
            self.bem_auto_data = []
            for i in range(self.number_of_modules):
                self.bem_manual_data.append(dfn.BEm_Module_Data())
                self.bem_auto_data.append(dfn.BEm_Module_Data())

            self.ui.connectButton.setEnabled(True)
            #check the communication port
            #self.scan_port()
    
    def connectToModules(self):
        self.ui.configModuleButton.setEnabled(False)
        self.ui.calibrationButton.setEnabled(False)
        #close the serial ports if they exists are they are open 
        #TODO gestion della riapertura
        '''
        for i in self.ipaddress:
            attribute = "Msocket"+str(i)
            if hasattr(self,attribute):
                if(getattr(self,attribute).isOpen()):
                    getattr(self,attribute).close()    
        '''
        #get all the selected ipaddress and check if all the selection are differents
        '''
        if(len(set(ipaddress)) != len(ipaddress)):
            #TODO ci va messo la dialogBox che dice che gli ip son ripetuti e indentato correttanebte ma finchè lavoro in loopback non posso
            return 
        else: #different IP selected
        '''
        
        for i in range(self.number_of_modules):
            setattr(self, 'Modulesocket' + str(i),socket.socket(socket.AF_INET, socket.SOCK_STREAM))
            #create an empty thread
            setattr(self, 'moduleThread' + str(i),QtCore.QThread())
            #create Workers for module threads
            setattr(self, 'moduleWorker' + str(i), COMWorker(str(i),getattr(self, 'Modulesocket' + str(i)),self.ipaddress[i]))
            getattr(self,'moduleWorker' + str(i)).moveToThread(getattr(self,'moduleThread' + str(i)))
            #connect signals of moduleThread with their slots
            getattr(self,'moduleThread' + str(i)).finished.connect(getattr(self,'moduleThread' + str(i)).deleteLater)
            getattr(self,'moduleThread' + str(i)).started.connect(getattr(self,'moduleWorker' + str(i)).run) #when the Thread is started the run function of the worked is called
            #create a message decoder and connect its data stream in to the module worket and its data stream out to the log/plotter function
            setattr(self, 'msgDecoder' + str(i),msgDecoder())
            getattr(self,'moduleWorker' + str(i)).recv_msg.connect(getattr(self,'msgDecoder'+str(i)).decode_data)
            getattr(self,'msgDecoder' + str(i)).decoded_msg.connect(self.plotnlog)

            #start the thread
            getattr(self,'moduleThread' + str(i)).start()
            
            self.ui.AModselCombo.addItem("Module "+str(i))
            self.ui.MModselCombo.addItem("Module "+str(i))
            self.ui.ChModuleCombo.addItem("Module "+str(i))
        
        self.ui.configModuleButton.setEnabled(True)
        self.ui.connectButton.setEnabled(False)
        #TODO rimuovere, è in più per velocizzare la connessione
        self.delay(100)
        self.configModel()
        
    def LoadCurrentFile(self):
        dialog_window = QtWidgets.QFileDialog(caption = "Chose the current profile file to read")
        dialog_window.setFileMode(QtWidgets.QFileDialog.ExistingFile)
        dialog_window.setNameFilter("Text files (*.txt)")
        #filenames = QtCore.QStringList()
    
        if(dialog_window.exec_()): #user selected "open file"; Dialog close or cancel return 0
            filename = dialog_window.selectedFiles() #returns a list of selected files; the first one is processed
            self.ui.currentProfileLabel.setText(filename[0])
         
    def ReadCurrentFile(self):
        profile_path = os.path.join('',self.ui.currentProfileLabel.text())
        if(os.path.isfile(profile_path)):
            filep = open(profile_path)
            lines = filep.readlines()
            filep.close()
            start_line = 0
            for index, line in enumerate(lines): 
                if(line.startswith('Time\tValue')):   #file valido
                    start_line = index + 1
            if (start_line == 0):
                print("wolla")
                return
                #TODO message box con errore di file non valido
            test_descriptor = lines[start_line:] #scarto le prime righe
            index = 0
            test_time = []
            test_current = []
            for line in test_descriptor: 
                try:
                    field = line.split('\t')
                    test_time.append(float(field[0]))
                    test_current.append(float(field[1]))
                except:
                    #TODO migliorare controllo
                    print("Errore durante il parsing del passo #" + str(index))
                    return
                index += 1
            self.test_time = [] 
            self.test_current = [] 
            for i in test_current:
                #CORREZIONE USCITA +5V anzichè +-12
                #self.test_current.append(round((i-param.curr_min)/(param.curr_max - param.curr_min)*65535))
                if(i <= param.curr_min or i >= param.curr_max):
                    self.test_current.append(param.half_val) #1.65V output
                else:
                    self.test_current.append(param.half_val + round(i*param.sens)) #canale +-75A 
            for i in test_time:
                self.test_time.append(round(i*1000))
            #TODO controllo accurato dei range
            self.currentprofileloaded = True
            if (self.currentprofileloaded and self.configdone):
                self.ui.runModelButton.setEnabled(True)
            
    def configModel(self):
        for i in range(self.number_of_modules):
            config_str = COM['start'] + COM['config'] + f"{self.battery_emulator[i].cell_num:04X}"+ f"{self.battery_emulator[i].curr_board:04X}" + \
                            f"{self.battery_emulator[i].temp_board:04X}" + COM['stop']
            getattr(self,'moduleWorker' + str(i)).send_message(config_str)
            self.delay(100)
            for j in range(self.battery_emulator[i].cell_num):
                config_str = COM['start'] + f"{int(COM['cellECM'],16)+j:02X}" + dfn.MODEL[self.battery_emulator[i].ECM_Model_type[j]]
                for elem in self.battery_emulator[i].OCV_SOC_LUT[j]:
                    config_str += f"{elem:04X}"
                config_str += self.float_to_hex(self.battery_emulator[i].R0[j]) + self.float_to_hex(self.battery_emulator[i].R1[j]) + \
                                self.float_to_hex(self.battery_emulator[i].C1[j]) + self.float_to_hex(self.battery_emulator[i].R2[j]) + \
                                self.float_to_hex(self.battery_emulator[i].C2[j]) + self.float_to_hex(self.battery_emulator[i].NominalCapacity[j]) + \
                                self.float_to_hex(self.battery_emulator[i].InitialSoc[j]) + COM['stop']
                getattr(self,'moduleWorker' + str(i)).send_message(config_str)
                self.delay(100)
            if(self.battery_emulator[i].curr_board):
                config_str = COM['start'] + COM['hallparam'] + self.float_to_hex(param.curr_min) + self.float_to_hex(param.curr_max) +  COM['stop']
                getattr(self,'moduleWorker' + str(i)).send_message(config_str)
                self.delay(50)
            else:
                self.bem_manual_data[i].curr_set = '-999.9'
                self.bem_manual_data[i].curr_read = '-999.9'
                self.bem_auto_data[i].curr_set = '-999.9'
                self.bem_auto_data[i].curr_read = '-999.9'

            if(self.battery_emulator[i].temp_board):
                config_str = COM['start'] + COM['ntcparam'] + self.float_to_hex(param.T0) + self.float_to_hex(param.r0) + self.float_to_hex(param.beta) + \
                                self.float_to_hex(param.rref) + self.float_to_hex(param.vref) +  COM['stop']
                getattr(self,'moduleWorker' + str(i)).send_message(config_str)
                self.delay(50)
            else:
                for j in range (self.max_cell_module):
                    self.bem_manual_data[i].temp_set[j] = '-273.15'
                    self.bem_manual_data[i].temp_read[j] = '-273.15'
                    self.bem_auto_data[i].temp_set[j] = '-273.15'
                    self.bem_auto_data[i].temp_read[j] = '-273.15'

            for j in range(self.battery_emulator[i].cell_num):
                config_str = COM['start'] + f"{int(COM['cellTherm'],16)+j:02X}" + dfn.MODEL[self.battery_emulator[i].THER_Model_type[j]] + self.float_to_hex(self.battery_emulator[i].InitialTemperature[j]) + COM['stop']
                getattr(self,'moduleWorker' + str(i)).send_message(config_str)
                self.delay(100)
            #thermal parameters
            config_str = COM['start'] + COM['thermalparam'] + self.float_to_hex(param.room_temp) + self.float_to_hex(param.res_coretoair) + self.float_to_hex(param.res_coretosup) + \
                                self.float_to_hex(param.cap_therm) +  COM['stop']
            getattr(self,'moduleWorker' + str(i)).send_message(config_str)
            self.delay(50)

        self.restoreModel()
        self.configdone = True
        self.ui.configModuleButton.setEnabled(False)
        self.ui.restoreButton.setEnabled(True)
        self.ui.calibrationButton.setEnabled(True)
        self.ui.setDefaultButton.setEnabled(True)
        self.ui.startManProfButton.setEnabled(True)
        if (self.currentprofileloaded and self.configdone):
            self.ui.runModelButton.setEnabled(True)
          
        #0-5 V current sensor initialization  
        _data = "0.0"
        data_hex = self.convertCurrToCode(_data)
        self.battery_emulator_manual[0][1][0] = data_hex
        msg = COM['manualCurrset'] + self.battery_emulator_manual[0][1][0] + COM['stop']
        getattr(self,'moduleWorker' + str(self.chModule)).send_message(msg)
        self.calibrate()

    def startManProfile(self):
        man_profile_path = os.path.join('',"profile.txt")
        if(os.path.isfile(man_profile_path)):
            mfilep = open(man_profile_path)
            lines = mfilep.readlines()
            mfilep.close()
            start_line = 0
            for index, line in enumerate(lines): 
                if(line.startswith('Time\tModule\tTarget_Type\tIndex\tValue')):   #file valido
                    start_line = index + 1
            if (start_line == 0):
                print("File non valido")
                return
                #TODO message box con errore di file non valido
            test_descriptor = lines[start_line:] #scarto le prime righe
            index = 0
            profile_time = []
            self.targ_module = []
            self.profile_targetType = []
            self.profile_targetIndex = []
            self.profile_value = []
            for line in test_descriptor: 
                try:
                    field = line.split('\t')
                    profile_time.append(float(field[0]))
                    self.targ_module.append(int(field[1]))
                    self.profile_targetType.append((field[2]))
                    self.profile_targetIndex.append(int(field[3]))
                    self.profile_value.append((field[4].strip()))
                except:
                    #TODO migliorare controllo
                    print("Errore durante il parsing del passo #" + str(index))
                    return
                index += 1
            self.profile_time = []
            #self.profile_targetType = []
            #self.profile_targetIndex = []
            #self.profile_value = []
            for i in profile_time:
                self.profile_time.append(round(i*1000))
            self.ui.restoreButton.setEnabled(False)
            self.ui.runModelButton.setEnabled(False)
            self.ui.setDefaultButton.setEnabled(False)
            self.ui.startManProfButton.setEnabled(False)
            self.ui.stopManProfButton.setEnabled(True)

            self.profilelast_run = 0
            self.profile_index = 0
            self.ProfileManager()
  
    def set_initstatus(self):
        for i in range(self.number_of_modules):
            #inizializza tensione
            _data = param.initV
            data_hex = self.convertCellToCode(_data)
            msgid = COM['manualCellset']
            msg = msgid
            for j in range(self.max_cell_module):
                self.battery_emulator_manual[i][0][j] = data_hex
                msg +=  self.battery_emulator_manual[i][0][j]
            msg += COM['stop']
            getattr(self,'moduleWorker' + str(i)).send_message(msg)
            self.delay(50)
            #inizializza corrente
            _data = param.initI
            data_hex = self.convertCurrToCode(_data)
            self.battery_emulator_manual[i][1][0] = data_hex
            msg = COM['manualCurrset'] + self.battery_emulator_manual[0][1][0] + COM['stop']
            getattr(self,'moduleWorker' + str(i)).send_message(msg)
            self.delay(50)
            #inizializza temperatura
            _data = param.initT
            #print(_data)
            data_hex = self.convertTempToCode(_data)
            msgid = COM['manualTempset']
            msg = msgid
            for j in range(self.max_cell_module):
                self.battery_emulator_manual[i][2][j] = data_hex
                msg +=  self.battery_emulator_manual[i][2][j]
            msg += COM['stop']
            getattr(self,'moduleWorker' + str(i)).send_message(msg)
                 
    def calibrate(self):
        for i in range(self.number_of_modules):
            calibration_str = COM['start'] + COM['calibration']
            for j in range(self.max_cell_module):
                calibration_str += self.float_to_hex(self.battery_emulator[i].dac_gain[j]) + self.float_to_hex(self.battery_emulator[i].dac_offset[j])
                calibration_str += self.float_to_hex(self.battery_emulator[i].adc_gainV[j]) + self.float_to_hex(self.battery_emulator[i].adc_offsetV[j])
                calibration_str += self.float_to_hex(self.battery_emulator[i].adc_gainI[j]) + self.float_to_hex(self.battery_emulator[i].adc_offsetI[j])
            calibration_str += self.float_to_hex(self.battery_emulator[i].dac_gainHn) + self.float_to_hex(self.battery_emulator[i].dac_gainHp) + self.float_to_hex(self.battery_emulator[i].dac_offsetH)
            calibration_str += self.float_to_hex(self.battery_emulator[i].adc_gainH) + self.float_to_hex(self.battery_emulator[i].adc_offsetH)
            calibration_str += COM['stop']
            #print(calibration_str)
            getattr(self,'moduleWorker' + str(i)).send_message(calibration_str)

    def runModel(self):
        for i in range(self.number_of_modules):
            for j in range (self.battery_emulator[i].cell_num):
                #print(self.battery_emulator[i].ECM_Model_type[j])
                if(self.battery_emulator[i].ECM_Model_type[j] == 'No_ECM_Model'):
                    #TODO mettere la box
                    print("modello sbagliato")
                    return
        self.ui.stopModelButton.setEnabled(True)
        self.ui.restoreButton.setEnabled(False)
        self.ui.runModelButton.setEnabled(False)
        self.ui.setDefaultButton.setEnabled(False)
        self.ui.startManProfButton.setEnabled(False)
        self.log_mode = 'auto'
        now = datetime.now() # current date and time
        filename = now.strftime("%Y_%m_%d__%H_%M_%S")
        for i in range(self.number_of_modules):
            filename = "logAuto_M" + str(i) + "_" + filename + '.txt'
            filep = os.path.join('log',filename)
            setattr(self, 'logfile' + str(i),open(filep, 'w'))
            header = "Date\tTime"
            for j in range(self.battery_emulator[i].cell_num):
                header += '\tVset' + str(j) + '[V]' +  '\tVread' + str(j) + '[V]' + '\tIcell' + str(j) + '[A]'
            if(self.battery_emulator[i].curr_board):
                header += '\tImodset[A]\tImodread[A]' 
            if(self.battery_emulator[i].temp_board):
                for j in range(self.battery_emulator[i].cell_num):
                    header += '\tT' +str(j) +'set[degC]\tT' + str(j) + 'read[degC]'
            header += '\n'
            getattr(self, 'logfile'+str(i)).write(header)
        self.last_run = 0
        self.test_index = 0
        msg = COM['start'] + COM['mode'] + f"{1:04X}" + COM['stop']
        for i in range(self.number_of_modules):
            getattr(self,'moduleWorker' + str(i)).send_message(msg)
        self.log_mode = 'auto'
        self.log_timer.start(dfn.LOG_PERIOD)
        self.ModelManager()
        
    def delay(self, msec_pause):
        """ function used to create a controlled delay still keeping the interface responsive
            Args:
                msec_pause: milliseconds to wait (int )
        """
        dieTime = QtCore.QTime.currentTime().addMSecs(msec_pause)
        while( QtCore.QTime.currentTime() < dieTime ):
            QtCore.QCoreApplication.processEvents( QtCore.QEventLoop.AllEvents, 100 )

    def float_to_hex(self, f):
        """function that return a string of 8 char which represent the hexadecimal representation of the float number passed as argument
        """
        return f"{struct.unpack('<I', struct.pack('<f', f))[0]:08X}"

    def plotnlog(self, data):
        #print(data)
        if(data[0].startswith('a')): #auto mode data
            module_id = int(data[0][1], 16)
            target = int(data[0][2], 16)
            if(target < 8): #cell data (string)
                self.bem_auto_data[module_id].cell_set[target] = data[1]
                self.bem_auto_data[module_id].cell_read[target] = data[2]
                self.bem_auto_data[module_id].cell_curr[target] = data[3]
                self.bem_auto_data[module_id].temp_set[target] = data[4]
                self.bem_auto_data[module_id].temp_read[target] = data[5]
                if(module_id == self.AutoVisualModule): #update labels
                    getattr(self.ui,'ACellSetLabel'+str(target)).setText(data[1])
                    getattr(self.ui,'ACellReadLabel'+str(target)).setText(data[2])
                    getattr(self.ui,'ACellCurrLabel'+str(target)).setText(data[3])
                    getattr(self.ui,'ATempSetLabel'+str(target)).setText(data[4])
                    getattr(self.ui,'ATempReadLabel'+str(target)).setText(data[5])
            elif(target == 8): #cell current, set and read
                self.bem_auto_data[module_id].curr_set = data[1]
                self.bem_auto_data[module_id].curr_read = data[2]
                if(module_id == self.AutoVisualModule): #update labels
                    getattr(self.ui,'ACurrSetLabel').setText(data[1])
                    getattr(self.ui,'ACurrReadLabel').setText(data[2])
            elif(target == 10): #synch data, data are ready to be logged  
                now = datetime.now() # current date and time
                log_line = now.strftime("%d/%m/%Y\t%H:%M:%S.%f")[:-3]
                for i in range(self.battery_emulator[module_id].cell_num):
                    log_line += '\t' + self.bem_auto_data[module_id].cell_set[i] + '\t' + self.bem_auto_data[module_id].cell_read[i] + '\t' + self.bem_auto_data[module_id].cell_curr[i]
                if(self.battery_emulator[module_id].curr_board):
                    log_line += '\t' + self.bem_auto_data[module_id].curr_set + '\t' + self.bem_auto_data[module_id].curr_read  
                if(self.battery_emulator[module_id].temp_board):
                    for i in range(self.battery_emulator[module_id].cell_num):
                        log_line += '\t' + self.bem_auto_data[module_id].temp_set[i] + '\t' + self.bem_auto_data[module_id].temp_read[i]
                log_line += '\n'
                if (not getattr(self, 'logfile'+str(module_id)).closed):
                    getattr(self, 'logfile'+str(module_id)).write(log_line) 
        elif(data[0].startswith('m')): #manual mode data
            
            module_id = int(data[0][1])
            target = int(data[0][2], 16)
            if(target < 8): #cell
                #print(data)
                self.bem_manual_data[module_id].cell_set[target] = data[1]
                self.bem_manual_data[module_id].cell_read[target] = data[2]
                self.bem_manual_data[module_id].cell_curr[target] = data[3]
                if(module_id == self.ManualVisualModule): #update labels
                    getattr(self.ui,'MCellSetLabel'+str(target)).setText(data[1])
                    getattr(self.ui,'MCellReadLabel'+str(target)).setText(data[2])
                    getattr(self.ui,'MCellCurrLabel'+str(target)).setText(data[3])
            elif(target == 8): #cell current, set and read
                self.bem_manual_data[module_id].curr_set = data[1]
                self.bem_manual_data[module_id].curr_read = data[2]
                if(module_id == self.ManualVisualModule): #update labels
                    getattr(self.ui,'MCurrSetLabel').setText(data[1])
                    getattr(self.ui,'MCurrReadLabel').setText(data[2])
            elif(target == 9): #temperature, set and read
                for i in range(self.max_cell_module):
                    self.bem_manual_data[module_id].temp_set[i] = data[1+i]
                    self.bem_manual_data[module_id].temp_read[i] = data[1+self.max_cell_module+i]
                    if(module_id == self.ManualVisualModule): #update labels
                        getattr(self.ui,'MTempSetLabel'+str(i)).setText(data[1+i])
                        getattr(self.ui,'MTempReadLabel'+str(i)).setText(data[1+self.max_cell_module+i])
            elif(target == 10): #synch data, data are ready to be logged
                now = datetime.now() # current date and time
                log_line = now.strftime("%d/%m/%Y\t%H:%M:%S.%f")[:-3]
                for i in range(self.battery_emulator[module_id].cell_num):
                    log_line += '\t' + self.bem_manual_data[module_id].cell_set[i] + '\t' + self.bem_manual_data[module_id].cell_read[i] + '\t' + self.bem_manual_data[module_id].cell_curr[i]
                log_line += '\t' + self.bem_manual_data[module_id].curr_set + '\t' + self.bem_manual_data[module_id].curr_read  
                for i in range(self.max_cell_module):
                    log_line += '\t' + self.bem_manual_data[module_id].temp_set[i] + '\t' + self.bem_manual_data[module_id].temp_read[i]
                log_line += '\n'
                if (not getattr(self, 'logfile'+str(module_id)).closed):
                    getattr(self, 'logfile'+str(module_id)).write(log_line) 
            
if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    window = Main()
    # window.resize(800,600)
    #window.setWindowIcon(QtGui.QIcon(os.path.join(os.getcwd(), 'images/file.png')))
    window.setWindowTitle("Battery Emulator Control Interface")
    window.show()
    sys.exit(app.exec_())



