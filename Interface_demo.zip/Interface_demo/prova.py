import os
man_profile_path = os.path.join('',"profile.txt")
if(os.path.isfile(man_profile_path)):
    mfilep = open(man_profile_path)
    lines = mfilep.readlines()
    mfilep.close()
    start_line = 0
    for index, line in enumerate(lines): 
        if(line.startswith('Time\tModule\tTarget_Type\tIndex\tValue')):   #file valido
            start_line = index + 1
    if (start_line == 0):
        print("File non valido")
    test_descriptor = lines[start_line:] #scarto le prime righe
    index = 0
    profile_times = []
    targ_module = []
    profile_targetType = []
    profile_targetIndex = []
    profile_value = []
    for line in test_descriptor: 
        #try:
        field = line.split('\t')
        print(field)
        profile_times.append(float(field[0]))
        targ_module.append(int(field[1]))
        profile_targetType.append((field[2]))
        profile_targetIndex.append(int(field[3]))
        profile_value.append(field[4].strip())
        '''
        except:
            #TODO migliorare controllo
            print("Errore durante il parsing del passo #" + str(index))
        '''
        index += 1
    profile_time = []
    #self.profile_targetType = []
    #self.profile_targetIndex = []
    #self.profile_value = []
    for i in profile_times:
        profile_time.append(round(i*1000))
    for i in range (len(profile_time)):
        print(str(profile_time[i])+'\t'+str(targ_module[i])+'\t'+profile_targetType[i]+'\t'+str(profile_targetIndex[i])+'\t'+str(profile_value[i]))