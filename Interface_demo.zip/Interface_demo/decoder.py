from PyQt5 import QtCore
from moduleWorker import COM
import parameters as param
import defines as dfn
import math
'''decoded message parsing: 
    the first element of the list is composed of 3 char xyz:
    - x: is 'a' or 'm' depending on the mode
    - y: contains the index of the module that provide data
    - z: 0 to 7 indicates a cell, 8 is the current, 9 is the temperatures, A is the synch signal
'''

class msgDecoder(QtCore.QObject):
    """Class that receive the incoming message from the serial communication, execute the parser and 
        provide the decoded info as a vector of string
    """
    #decoded_msg = QtCore.pyqtSignal([str])
    decoded_msg = QtCore.pyqtSignal(list)
    def __init__(self, module = 0):
        QtCore.QObject.__init__(self)
        self.module = module
        self.max_cell_module = 8

    def decode_data(self, _msg = ""):
        """function used to decode the incoming message
            The first and the second char are the ID of the message, using this one the msg is parsed
        """
        msg_list = _msg.split('\n')
        msg_list.pop(-1)
        for msg in msg_list:
            #print("msg:\t", end = '')
            #print(msg)
            ID = msg[0:2]
            dec_msg = []
            if(ID == COM['recvautocurr']):
                dec_msg.append('a'+str(self.module)+'8')
                dec_msg.append(self.decode_i_set(msg[2:6]))
                dec_msg.append(self.decode_i_read(msg[6:10]))
            elif(ID[0] == ((COM['recvautocell'])[0])):
                dec_msg.append('a' + str(self.module) + ID[1])
                dec_msg.append(self.decode_v_set(msg[2:6]))
                dec_msg.append(self.decode_v_read(msg[6:10]))
                dec_msg.append(self.decode_v_curr(msg[10:14]))
                dec_msg.append(self.decode_t(msg[14:18]))
                dec_msg.append(self.decode_t(msg[18:22]))
            elif(ID == COM['recvmanualcurr']):
                dec_msg.append('m'+str(self.module)+'8')
                dec_msg.append(self.decode_i_set(msg[2:6]))
                dec_msg.append(self.decode_i_read(msg[6:10]))
            elif(ID == COM['recvmanualtemp']):
                dec_msg.append('m'+str(self.module)+'9')
                for i in range(2*self.max_cell_module):
                    dec_msg.append(self.decode_t(msg[2+4*i:6+4*i]))
            elif(ID[0] == ((COM['recvmanualcell'])[0])):
                #print("visto")
                dec_msg.append('m' + str(self.module) + ID[1])
                dec_msg.append(self.decode_v_set(msg[2:6]))
                dec_msg.append(self.decode_v_read(msg[6:10]))
                dec_msg.append(self.decode_v_curr(msg[10:14]))
            elif(ID == COM['datasynchmanu']):
                dec_msg.append('m'+str(self.module)+'A')
            elif(ID == COM['datasynchauto']):
                dec_msg.append('a'+str(self.module)+'A')
            #print("decoded:\t", end = '')
            #print(dec_msg)
            self.decoded_msg.emit(dec_msg) 
            
        


    def decode_v_set(self, msg):
        code = int(msg,16) #convert hexadecimal string in integer
        value = float(code) / 65536.0 * 5.0
        value_str = f"{value:.4f}"
        return value_str

    def decode_v_read(self, msg):
        code = int(msg,16) #convert hexadecimal string in integer
        #print(code, end = '\t')
        """
        if code & (1 << (16 - 1)):
            code -= 1 << 16
        print(code, end = '\t')
        """
        value = float(code) / 65536.0 * 2.0 * 2.40 * 2.0 #* 59.0 / 39.0 #keep in count voltage divider and Vref
        if(value >= 5.5 ):
            value = 0.0
        value_str = f"{value:.4f}"
        return value_str

    def decode_v_curr(self, msg):
        value = int(msg,16) #convert hexadecimal string in integer
        if value & (1 << (16 - 1)):
            value -= 1 << 16
        _value = float(value) / 65536.0 * 2.0 * 2.40 * 4.0 * 2  #keep in count voltage divider , Vref, shunt, and INA gain (and 2x correction)
        value_str = f"{_value:.4f}"
        return value_str
    
    def decode_i_set(self, msg):
        code = int(msg,16) #convert hexadecimal string in integer
        """CODICE PER SENSORE +-12V
        value = float(code) / 65536.0 * (param.curr_max - param.curr_min) + param.curr_min
        """
        #CODICE PER SENSORE 0-3.3V
        value = (float(code) - param.half_val) / param.sens
        value_str = f"{value:.3f}"
        return value_str

    def decode_i_read(self, msg):
        code = int(msg,16) #convert hexadecimal string in integer
        #print(code)
        """CODICE PER SENSORE +-12V
        value = float(code) / 16384.0 * 1.024 * (param.curr_max - param.curr_min) + 1.024 * param.curr_min
        """
        #CODICE PER SENSORE 0-3.3V
        value = (float(code) - 5280.0) * 0.01773 #5280 è il codice di 1.65V e l'altro magic number è A/codice della pendenza della curva
        value_str = f"{value:.3f}"
        return value_str

    def decode_t(self,msg):
        code = int(msg,16) #convert hexadecimal string in integer
        if code == 0: #avoid math domain error (division by 0 or log(0))
            code =1
        aux = float(code) / 4096.0 * 5.0 #voltage
        try:
            value = 1.0/((1.0/param.T0) + ((1.0/param.beta)*math.log((aux*param.rref)/((param.vref - aux)*param.r0))))
            value -= 273.15 #kelvin to celsius degree conversion
            value_str = f"{value:.1f}"
        except:
            value_str = "9999"
        return value_str






        


