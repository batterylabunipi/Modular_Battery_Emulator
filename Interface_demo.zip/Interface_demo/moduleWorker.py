from PyQt5 import QtCore
import defines as dfn

RECVSIZE = 1024

COM = {
    'start'         : '',
    'stop'          : '\n',
    'config'        : '00',
    'calibration'   : '01',
    'restoreECM'    : '02',
    'datarequest'   : '0A',
    'cellECM'       : '10', 
    'cellTherm'     : '18',
    'hallparam'     : '20',
    'ntcparam'      : '21', 
    'thermalparam'  : '22',
    'manualCellset' : '40',
    'manualCurrset' : '41',
    'manualTempset' : '42',
    'modelCurr'     : '70',
    'mode'          : '7F',
    'datasynchauto' : '80',
    'datasynchmanu' : '81',  
    'recvautocell'  : '90',
    'recvautocurr'  : '98',
    'recvmanualcell': 'A0',
    'recvmanualcurr': 'A8',
    'recvmanualtemp': 'A9'
}

class COMWorker(QtCore.QObject):
    """ class for the Worker of the serial communication manager
    The passed arguments at the initialization are the index of the module (as string) and the COM PORT "client". 
    """
    recv_msg = QtCore.pyqtSignal(str) # # for sending data to the parser
    recv_error = QtCore.pyqtSignal(str)# for errors
    #msg = QtCore.pyqtSignal(str) # for the start/end message

    def __init__(self, module_index, socket, ipaddress): 
        super(COMWorker,self).__init__()
        self.socket = socket
        self.ipaddr = ipaddress
        #self.m_sLastError = ""
        self.module_index = module_index
        self.alive = True
        #Signals for comunication with GUI
        
 
    #send a given message over the communication channel 
    def send_message(self, tx_string):
        msg = bytes(tx_string, 'utf-8') 
        #length = bytes("%.4x" % len(msg), "utf-8")
        #self.socket.send(length)
        #5print(tx_string)
        self.socket.send(msg)

    def stop(self):
        """Stop the thread from running"""
        self.alive = False
    
    def wait(self, msec_pause):
        """ function used to create a controlled delay still keeping the interface responsive
        """
        dieTime = QtCore.QTime.currentTime().addMSecs(msec_pause)
        while( QtCore.QTime.currentTime() < dieTime ):
            QtCore.QCoreApplication.processEvents( QtCore.QEventLoop.AllEvents, 100 )
    
    def run(self):
        #connect to the server
        self.socket.connect((self.ipaddr, dfn.TCP_PORT))  # connect to the server
        """Thred run loop"""
        while self.alive:
            msg = self.socket.recv(RECVSIZE)
            try:
                msg = msg.decode("utf-8")
                #print(msg,end="")
                self.recv_msg.emit(msg)
            except:
                self.recv_error.emit("errore")
                break
        
        if error != None:
            self.recv_error.emit(error)
        self.alive = True 