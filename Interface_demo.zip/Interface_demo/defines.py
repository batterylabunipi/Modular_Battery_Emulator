from dataclasses import dataclass

max_module = 8
default_config_path = '.\config.txt'
TCP_PORT = 7
LOG_PERIOD = 1000 #in ms

initV = "3.2"   #[V]
initI = "0.0"   #[A]
initT = "25.0"  #[°C]

MODEL = {
    'No_ECM_Model'          : '0000',
    'OCV_SOC_Model'         : '0001',
    'Rint_Model'            : '0002',
    '1RC_Model'             : '0003',
    '2RC_Model'             : '0004',
    'No_Thermal_Model'      : '0000',
    'Lumped_Thermal_Model'  : '0001'
}


@dataclass
class Battery_Module:
    cell_num: int
    temp_board: bool 
    curr_board: bool 
    ECM_Model_type: [str, str, str, str, str, str, str, str]
    THER_Model_type: [str, str, str, str, str, str, str, str]
    dac_gainHn: float 
    dac_gainHp: float 
    dac_offsetH: float
    adc_gainH : float
    adc_offsetH: float
    OCV_SOC_LUT: [[int], [int], [int], [int], [int], [int], [int], [int], [int], [int], [int]]
    R0: [float, float, float, float, float, float, float, float ]
    R1: [float, float, float, float, float, float, float, float ]
    C1: [float, float, float, float, float, float, float, float ]
    R2: [float, float, float, float, float, float, float, float ]
    C2: [float, float, float, float, float, float, float, float ]
    NominalCapacity: [float, float, float, float, float, float, float, float ]
    InitialSoc: [float, float, float, float, float, float, float, float ]
    InitialTemperature: [float, float, float, float, float, float, float, float ]
    dac_gain = [float, float, float, float, float, float, float, float ]
    dac_offset = [float, float, float, float, float, float, float, float ]
    adc_gainV = [float, float, float, float, float, float, float, float ]
    adc_offsetV = [float, float, float, float, float, float, float, float ]
    adc_gainI = [float, float, float, float, float, float, float, float ]
    adc_offsetI = [float, float, float, float, float, float, float, float ]
    
    def __init__(self, cell_num: int, temp_board: bool, curr_board: bool, dac_gainHn : float, dac_gainHp: float,  dac_offsetH: float, adc_gainH: float, adc_offsetH: float, ECM_Model_type: [str],  THER_Model_type: [str], OCV_SOC_LUT:[float], R0:float, R1: float, C1: float, R2: float, C2: float, 
                        InitialTemperature: float, NominalCapacity: float , InitialSoc: float, dac_gain: float, dac_offset: float, adc_gainV: float, adc_offsetV: float, adc_gainI: float, adc_offsetI: float):
        self.cell_num = cell_num
        self.temp_board = temp_board
        self.curr_board = curr_board
        self.dac_gainHn = dac_gainHn
        self.dac_gainHp = dac_gainHp
        self.dac_offsetH = dac_offsetH
        self.adc_gainH = adc_gainH
        self.adc_offsetH = adc_offsetH
        self.ECM_Model_type = ECM_Model_type
        self.THER_Model_type = THER_Model_type
        self.OCV_SOC_LUT = OCV_SOC_LUT
        self.R0 = R0
        self.R1 = R1
        self.C1 = C1
        self.R2 = R2
        self.C2 = C2
        self.InitialTemperature = InitialTemperature
        self.NominalCapacity = NominalCapacity
        self.InitialSoc = InitialSoc
        self.dac_gain = dac_gain
        self.dac_offset = dac_offset
        self.adc_gainV = adc_gainV
        self.adc_offsetV = adc_offsetV
        self.adc_gainI = adc_gainI
        self.adc_offsetI = adc_offsetI


@dataclass
class BEm_Module_Data:
    cell_set:   [str, str, str, str, str, str, str, str]
    cell_read:  [str, str, str, str, str, str, str, str]
    cell_curr:  [str, str, str, str, str, str, str, str]
    curr_set:   str
    curr_read:  str
    temp_set:   [str, str, str, str, str, str, str, str]
    temp_read:  [str, str, str, str, str, str, str, str]

    def __init__(self):
        self.cell_set   = ['','','','','','','','']
        self.cell_read  = ['','','','','','','','']
        self.cell_curr  = ['','','','','','','','']
        self.curr_set   = ''
        self.curr_read  = ''
        self.temp_set   = ['','','','','','','','']
        self.temp_read  = ['','','','','','','','']
